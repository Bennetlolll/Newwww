#!/usr/bin/env bash
# ZypeHost Pterodactyl Theme v10 — installer
# v10 adds: swapped login card layout (form left / logo right), a real
# Impressum instead of placeholders, a redesigned brand mark, and a new
# "Z" favicon set that replaces Pterodactyl's default falcon favicon.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT_DIR/theme/public/themes/zypehost"
FAVICON_SRC="$ROOT_DIR/theme/public/favicons"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PANEL_DIR/storage/zypehost-backups/v10-$STAMP"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"

fail(){ echo "[ZypeHost v10] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost v10] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$TARGET" ]] || fail "LoginFormContainer.tsx nicht gefunden: $TARGET"
[[ -f "$SRC/background.jpeg" ]] || fail "background.jpeg fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-logo.png" ]] || fail "zypehost-logo.png fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-icon.png" ]] || fail "zypehost-icon.png fehlt im Theme-Ordner"
[[ -f "$SRC/dashboard-bg.jpg" ]] || fail "dashboard-bg.jpg fehlt im Theme-Ordner"
[[ -d "$FAVICON_SRC" ]] || fail "favicons-Ordner fehlt im Theme-Ordner"
[[ -f "$ROOT_DIR/serverside/controllers/SupportLoginController.php" ]] || fail "Support-Login-Controller fehlt im Theme-Ordner"
[[ -f "$ROOT_DIR/serverside/commands/ZypeHostSupportPin.php" ]] || fail "Support-PIN-Command fehlt im Theme-Ordner"
[[ -f "$ROOT_DIR/serverside/routes/zypehost-support.php" ]] || fail "Support-Routen-Datei fehlt im Theme-Ordner"
[[ -f "$ROOT_DIR/serverside/migrations/2026_09_23_000000_add_support_pin_to_users_table.php" ]] || fail "Support-PIN-Migration fehlt im Theme-Ordner"

mkdir -p "$BACKUP"
cp -a "$TARGET" "$BACKUP/LoginFormContainer.tsx"
[[ -f "$WRAPPER" ]] && cp -a "$WRAPPER" "$BACKUP/wrapper.blade.php" || true
[[ -d "$FAVICON_DIR" ]] && cp -a "$FAVICON_DIR" "$BACKUP/favicons" || true
[[ -f "$PANEL_DIR/.env" ]] && cp -a "$PANEL_DIR/.env" "$BACKUP/.env" || true
info "Backup gespeichert unter: $BACKUP"

# --- Step 1: HARD RESET so nothing from v2/v3/v4/v5 can survive -----------
cd "$PANEL_DIR"
if [[ -d .git ]]; then
    info "Git-Repo erkannt — setze wrapper.blade.php und LoginFormContainer.tsx auf den Original-Stand zurück..."
    git checkout -- \
        "resources/views/templates/wrapper.blade.php" \
        "resources/scripts/components/auth/LoginFormContainer.tsx" 2>/dev/null || \
        info "Hinweis: git checkout konnte eine der Dateien nicht zurücksetzen (evtl. schon sauber)."
else
    info "Kein Git-Repo gefunden — entferne alte ZypeHost-Marker per Textsuche stattdessen."
    if [[ -f "$WRAPPER" ]]; then
        python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
# strip every historical marker pair, whatever version made it
for marker in ('ZYPEHOST_V6_ASSETS', 'ZYPEHOST_V5_ASSETS', 'ZYPEHOST_V4_ASSETS', 'ZYPEHOST_V3_ASSETS', 'ZYPEHOST_V2_ASSETS'):
    s = re.sub(r'<!--\s*' + re.escape(marker) + r'\s*-->.*?<!--\s*/' + re.escape(marker) + r'\s*-->\s*', '', s, flags=re.S)
# safety net: also strip any leftover comment block that just mentions zypehost
s = re.sub(r'<!--[^>]*zypehost[^>]*-->.*?<!--[^>]*/[^>]*zypehost[^>]*-->\s*', '', s, flags=re.S | re.I)
p.write_text(s, encoding='utf-8')
PY
    fi
fi

# --- Step 2: wipe old theme assets completely, then lay down fresh ones ---
rm -rf "$ASSET_DIR"
mkdir -p "$ASSET_DIR"
cp -f "$SRC/background.jpeg" "$ASSET_DIR/background.jpeg"
cp -f "$SRC/zypehost-logo.png" "$ASSET_DIR/zypehost-logo.png"
cp -f "$SRC/zypehost-icon.png" "$ASSET_DIR/zypehost-icon.png"
cp -f "$SRC/dashboard-bg.jpg" "$ASSET_DIR/dashboard-bg.jpg"
# User-selected server-list background. Download it when the panel is installed;
# the CSS below also keeps the exact raw URL as a fallback.
SERVER_LIST_BG_URL="https://raw.githubusercontent.com/Bennetlolll/Newwww/0ff3ca565fa457d91aa7a4da8f56d3964977efec/IMG_2044.png"
if command -v curl >/dev/null 2>&1; then
    curl -fsSL --retry 2 "$SERVER_LIST_BG_URL" -o "$ASSET_DIR/IMG_2044.png" 2>/dev/null || true
elif command -v wget >/dev/null 2>&1; then
    wget -q "$SERVER_LIST_BG_URL" -O "$ASSET_DIR/IMG_2044.png" 2>/dev/null || true
fi

# --- Step 3: write the new single-card component (full overwrite) --------
cp -f "$ROOT_DIR/theme/LoginFormContainer.tsx" "$TARGET"

# --- Step 3b: replace the default Pterodactyl favicon with the ZypeHost
#     "Z" mark (same filenames, so no blade/template edits are needed) ----
mkdir -p "$FAVICON_DIR"
# Overwrite EVERY icon file Pterodactyl's default favicon set ships with
# (android-icon-*, apple-icon-*, ms-icon-*, mstile-*, favicon-96x96, the
# favicon.ico that lives inside public/favicons/, plus the Safari pinned-tab
# SVG) so no old falcon file can survive in any size/format a browser might
# prefer over the ones we already knew about.
cp -f "$FAVICON_SRC"/*.png "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC"/*.svg "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$FAVICON_DIR/favicon.ico" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$PANEL_DIR/public/favicon.ico" 2>/dev/null || true
info "Favicon ersetzt (Falke -> Z), komplettes Set inkl. Apple/Android/MS-Icons und Safari-Pinned-Tab."

# --- Step 3c: force browsers to actually fetch the new favicons -----------
# Pterodactyl's default wrapper.blade.php links to /favicons/... with no
# cache-busting query string at all, so browsers that already cached the
# old falcon icons keep showing them forever even though the files on disk
# are correct. Fix: append/refresh a "?v=<timestamp>" query on every
# favicon-related href/content in wrapper.blade.php so each install forces
# a guaranteed-fresh fetch, independent of any browser cache.
if [[ -f "$WRAPPER" ]]; then
    FAVICON_STAMP="$STAMP" python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import os, re, sys

p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
stamp = os.environ['FAVICON_STAMP']

def bust(match):
    attr, path = match.group(1), match.group(2)
    path = re.sub(r'\?v=[^"\']*', '', path)  # drop any previous cache-buster
    return f'{attr}="{path}?v={stamp}"'

# Matches href="/favicons/..." and content="/favicons/..." (browserconfig meta)
s = re.sub(r'(href|content)="(/favicons/[^"]*)"', bust, s)
p.write_text(s, encoding='utf-8')
PY
    info "Cache-Buster auf Favicon-Links in wrapper.blade.php gesetzt (?v=$STAMP) — Browser MUSS neu laden."

    # --- Step 3d: dashboard-only background (never on the login screen) --
    # wrapper.blade.php already knows whether someone is logged in — it uses
    # Auth::user() further down to decide whether to print window.PterodactylUser.
    # We reuse that exact same check on the <body> tag: only when the user IS
    # authenticated (dashboard / server pages) do we add a class that paints
    # the new background. The login/forgot-password/reset screens run through
    # AuthenticationRouter with no authenticated user, so Auth::user() is null
    # there and the class — and therefore the image — never appears.
    python3 - "$WRAPPER" "$STAMP" <<'PY'
from pathlib import Path
import re, sys

p = Path(sys.argv[1])
stamp = sys.argv[2]
s = p.read_text(encoding='utf-8')

body_tag_match = re.search(r'<body[^>]*>', s)
already_patched = bool(body_tag_match) and 'zypehost-dashboard-bg' in body_tag_match.group(0)

body_re = re.compile(r'<body class="\{\{\s*\$css\[\'body\'\]\s*\?\?\s*\'([^\']*)\'\s*\}\}">')
if already_patched:
    pass  # already patched by a previous install run, leave the <body> tag alone
elif body_re.search(s):
    s = body_re.sub(
        lambda m: (
            '<body class="{{ $css[\'body\'] ?? \'' + m.group(1) + '\' }}'
            ' @if(!is_null(Auth::user())) zypehost-dashboard-bg @endif">'
        ),
        s,
        count=1,
    )
else:
    # Fallback: whatever the body tag looks like, just tack the same
    # conditional class onto it so this still works on unexpected markup.
    s = re.sub(
        r'<body class="([^"]*)">',
        lambda m: f'<body class="{m.group(1)} @if(!is_null(Auth::user())) zypehost-dashboard-bg @endif">',
        s,
        count=1,
    )

css_block = (
    "<style>\n"
    ".zypehost-dashboard-bg {\n"
    "  background:\n"
    "    linear-gradient(rgba(8,12,18,.55), rgba(8,12,18,.72)),\n"
    "    url(\'https://raw.githubusercontent.com/Bennetlolll/Newwww/0ff3ca565fa457d91aa7a4da8f56d3964977efec/IMG_2044.png\') center center / cover no-repeat fixed !important;\n"
    "}\n"
    "/* Pterodactyl's panels/cards use Tailwind colour utilities, which are\n"
    "   fully opaque by default and completely cover any body background.\n"
    "   Tailwind's color utilities read their alpha from the --tw-bg-opacity\n"
    "   custom property, so lowering it (instead of guessing exact class\n"
    "   names, which change between panel versions) lets the new background\n"
    "   image show through everywhere at once. Modals/popups are kept solid\n"
    "   via #modal-portal so dialogs stay easy to read. */\n"
    ".zypehost-server-list-head { display:flex; align-items:center; justify-content:space-between; gap:1rem; margin:0 0 1rem; flex-wrap:wrap; }\n"
    ".zypehost-greeting { color:#fff; font-size:1.35rem; font-weight:800; letter-spacing:-.02em; text-shadow:0 2px 12px rgba(0,0,0,.35); margin:0; }\n"
    ".zypehost-customer-no { opacity:.72; font-size:.85em; font-weight:600; }\n"
    ".zypehost-list-support { display:inline-flex !important; align-items:center; gap:.45rem; background:rgba(17,24,39,.78) !important; color:#fff !important; border:1px solid rgba(255,255,255,.18) !important; border-radius:.7rem !important; padding:.55rem .9rem !important; box-shadow:0 8px 22px rgba(0,0,0,.25); }\n"
    ".zypehost-list-support:hover { background:rgba(17,24,39,.95) !important; }\n"
    ".zypehost-dashboard-bg * {\n"
    "  --tw-bg-opacity: 0.55 !important;\n"
    "}\n"
    ".zypehost-dashboard-bg #modal-portal *,\n"
    ".zypehost-dashboard-bg [role='dialog'] * {\n"
    "  --tw-bg-opacity: 0.94 !important;\n"
    "}\n"
    "/* Nicer buttons + server-list rows, panel-version independent (no core\n"
    "   TSX files touched, so this survives Pterodactyl updates). */\n"
    "button, a[href^='/server/'] {\n"
    "  transition: transform .12s ease, filter .12s ease, box-shadow .12s ease !important;\n"
    "}\n"
    "button:hover {\n"
    "  filter: brightness(1.12);\n"
    "  transform: translateY(-1px);\n"
    "}\n"
    "button:active {\n"
    "  transform: translateY(0);\n"
    "  filter: brightness(0.96);\n"
    "}\n"
    "a[href^='/server/'] {\n"
    "  border-radius: 0.75rem !important;\n"
    "  overflow: hidden;\n"
    "}\n"
    "a[href^='/server/']:hover {\n"
    "  transform: translateY(-2px);\n"
    "  box-shadow: 0 10px 24px rgba(0,0,0,.35) !important;\n"
    "}\n"
    "</style>\n"
)
if '.zypehost-dashboard-bg {' not in s:
    s = s.replace('</head>', css_block + '</head>')
else:
    s = re.sub(r"<style>\n\.zypehost-dashboard-bg.*?</style>\n", css_block, s, flags=re.S)

# --- Step 3e: rebrand the built-in "Pterodactyl® © 2015 - <year>" footer -
# That footer text lives inside Pterodactyl's own React components (not
# something this theme ships/overwrites), and its exact file/markup shifts
# between panel versions. Instead of guessing the source file, a small,
# self-contained script finds that exact text wherever it renders and swaps
# only the "Pterodactyl(R)" part for "ZypeHost", leaving "(c) 2015 - year"
# intact. Wrapped in a marker so re-running install.sh never duplicates it.
footer_marker_open = '<!-- ZYPEHOST_FOOTER_BRAND -->'
footer_marker_close = '<!-- /ZYPEHOST_FOOTER_BRAND -->'
s = re.sub(
    re.escape(footer_marker_open) + r'.*?' + re.escape(footer_marker_close) + r'\s*',
    '',
    s,
    flags=re.S,
)
footer_script = (
    footer_marker_open + "\n"
    "<script>\n"
    "(function () {\n"
    "  function rebrandText() {\n"
    "    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);\n"
    "    var node;\n"
    "    while ((node = walker.nextNode())) {\n"
    "      if (node.nodeValue.indexOf('Pterodactyl') !== -1) {\n"
    "        node.nodeValue = node.nodeValue.replace(/Pterodactyl\\u00AE?/g, 'ZypeHost');\n"
    "      }\n"
    "    }\n"
    "  }\n"
    "  // The dashboard's big page-level wrapper divs are fully opaque, no\n"
    "  // matter what colour utility framework built them, so a background\n"
    "  // set on <body> alone never shows through. Rather than guess exact\n"
    "  // class names (which differ between panel versions), read each large\n"
    "  // element's REAL computed background colour at runtime and only make\n"
    "  // the big, dark, fully-opaque wrapper elements translucent — small\n"
    "  // elements (buttons, badges, status pills) and light/white elements\n"
    "  // (modal cards, the login form) are left completely alone.\n"
    "  function ghostBigBackgrounds() {\n"
    "    if (!document.body.classList.contains('zypehost-dashboard-bg')) return;\n"
    "    var vh = window.innerHeight, vw = window.innerWidth;\n"
    "    var els = document.querySelectorAll('#app, #app *');\n"
    "    for (var i = 0; i < els.length; i++) {\n"
    "      var el = els[i];\n"
    "      if (el.dataset.zypehostGhosted === '1') continue;\n"
    "      var rect = el.getBoundingClientRect();\n"
    "      if (rect.width < vw * 0.6 || rect.height < vh * 0.35) continue;\n"
    "      var cs = getComputedStyle(el);\n"
    "      var m = cs.backgroundColor && cs.backgroundColor.match(/rgba?\\(([\\d.]+),\\s*([\\d.]+),\\s*([\\d.]+)(?:,\\s*([\\d.]+))?\\)/);\n"
    "      if (!m) continue;\n"
    "      var r = +m[1], g = +m[2], b = +m[3];\n"
    "      var a = m[4] !== undefined ? parseFloat(m[4]) : 1;\n"
    "      if (a < 0.85) continue;\n"
    "      if ((r + g + b) > 380) continue;\n"
    "      el.style.setProperty('background-color', 'rgba(' + r + ',' + g + ',' + b + ',0.32)', 'important');\n"
    "      el.dataset.zypehostGhosted = '1';\n"
    "    }\n"
    "  }\n"
    "  function serverListUI() {\n"
    "    if (!document.body.classList.contains('zypehost-dashboard-bg')) return;\n"
    "    var links=Array.prototype.slice.call(document.querySelectorAll('a[href^=\\\"/server/\\\"]')); if(!links.length) return;\n"
    "    var row=links[0].closest('li, [role=\\\"listitem\\\"], article') || links[0]; var parent=row.parentElement || row;\n"
    "    var head=document.getElementById('zypehost-server-list-head'); if(head) return;\n"
    "    head=document.createElement('div'); head.id='zypehost-server-list-head'; head.className='zypehost-server-list-head';\n"
    "    var title=document.createElement('div'); title.id='zypehost-greeting'; title.className='zypehost-greeting';\n"
    "    var h=new Date().getHours(); var g=(h>=5&&h<12)?'Guten Morgen':(h>=12&&h<18)?'Hallo':(h>=18)?'Guten Abend':'Noch Wach';\n"
    "    var u='User'; try { if(window.PterodactylUser && window.PterodactylUser.username) u=window.PterodactylUser.username; } catch(e) {}\n"
    "    if(u==='User'){var ue=document.querySelector('[data-user], .user-menu .username, [class*=username]');if(ue)u=(ue.getAttribute('data-user')||ue.textContent||'User').trim();}\n"
    "    var key='zypehost_customer_number',no=null;try{no=localStorage.getItem(key);}catch(e){}\n"
    "    if(!no||!/^[0-9]{6}$/.test(no)){no=String(Math.floor(100000+Math.random()*900000));try{localStorage.setItem(key,no);}catch(e){}}\n"
    "    title.textContent=g+' @'+u+' #'; var num=document.createElement('span'); num.className='zypehost-customer-no'; num.textContent=no; title.appendChild(num); head.appendChild(title);\n"
    "    var support=document.getElementById('zypehost-support-open'); if(support){support.style.display='inline-flex';support.classList.add('zypehost-list-support');head.appendChild(support);}\n"
    "    parent.parentNode.insertBefore(head,parent);\n"
    "  }\n"
    "  function runAll() { rebrandText(); ghostBigBackgrounds(); serverListUI(); }\n"

    "  // Debounced: the server console streams log lines into the DOM\n"
    "  // constantly, so an observer callback that runs on every single\n"
    "  // mutation would re-scan the whole page far too often. Collapse\n"
    "  // bursts down to at most one scan per second instead.\n"
    "  var pending = null;\n"
    "  function scheduleRun() {\n"
    "    if (pending) return;\n"
    "    pending = setTimeout(function () { pending = null; runAll(); }, 1000);\n"
    "  }\n"
    "  document.addEventListener('DOMContentLoaded', function () {\n"
    "    runAll();\n"
    "    setTimeout(runAll, 800);\n"
    "    new MutationObserver(scheduleRun).observe(document.body, { childList: true, subtree: true });\n"
    "    setInterval(serverListUI, 30000);\n"
    "  });\n"
    "})();\n"
    "</script>\n"
    + footer_marker_close + "\n"
)
s = s.replace('</body>', footer_script + '</body>')

# --- Step 3f: Support-PIN widget (root_admin only) -------------------------
# Floating button (not pixel-glued to the settings gear, since its exact
# on-screen position shifts between panel versions/screen sizes — a fixed
# corner button stays correct everywhere) that lets an already-authenticated
# root_admin enter a customer's fixed Support-PIN and get logged in as that
# customer. Server-side, SupportLoginController re-checks root_admin on
# every request — this Blade @if only controls whether the button is
# rendered, it grants no access by itself. A bottom banner with a
# "back to admin" action appears while a support session is active.
support_marker_open = '<!-- ZYPEHOST_SUPPORT_WIDGET -->'
support_marker_close = '<!-- /ZYPEHOST_SUPPORT_WIDGET -->'
s = re.sub(
    re.escape(support_marker_open) + r'.*?' + re.escape(support_marker_close) + r'\s*',
    '',
    s,
    flags=re.S,
)
support_widget = (
    support_marker_open + "\n"
    "@if(!is_null(Auth::user()) && Auth::user()->root_admin)\n"
    "<button id=\"zypehost-support-open\" type=\"button\" "
    "style=\"display:none;background:#111827;"
    "color:#fff;border:1px solid #374151;border-radius:9999px;padding:.6rem 1.1rem;"
    "font-size:.85rem;font-weight:600;cursor:pointer;box-shadow:0 6px 18px rgba(0,0,0,.4);\">"
    "&#128100; Support</button>\n"
    "<div id=\"zypehost-support-modal\" style=\"display:none;position:fixed;inset:0;"
    "z-index:10000;background:rgba(0,0,0,.6);align-items:center;justify-content:center;\">\n"
    "  <div style=\"background:#111827;border:1px solid #374151;border-radius:.75rem;"
    "padding:1.5rem;width:min(90vw,320px);\">\n"
    "    <h3 style=\"color:#fff;margin:0 0 .75rem;font-size:1rem;\">Support-Login</h3>\n"
    "    <input id=\"zypehost-pin-input\" type=\"text\" inputmode=\"numeric\" "
    "placeholder=\"Support-PIN des Kunden\" style=\"width:100%;box-sizing:border-box;"
    "padding:.6rem;border-radius:.4rem;border:1px solid #374151;background:#1f2937;"
    "color:#fff;margin-bottom:.5rem;font-size:1rem;\">\n"
    "    <div id=\"zypehost-pin-error\" style=\"color:#f87171;font-size:.8rem;"
    "min-height:1.2em;margin-bottom:.5rem;\"></div>\n"
    "    <div style=\"display:flex;gap:.5rem;justify-content:flex-end;\">\n"
    "      <button id=\"zypehost-pin-cancel\" type=\"button\" style=\"background:transparent;"
    "color:#9ca3af;border:none;padding:.5rem .8rem;cursor:pointer;\">Abbrechen</button>\n"
    "      <button id=\"zypehost-pin-submit\" type=\"button\" style=\"background:#2563eb;"
    "color:#fff;border:none;border-radius:.4rem;padding:.5rem 1rem;cursor:pointer;"
    "font-weight:600;\">Einloggen</button>\n"
    "    </div>\n"
    "  </div>\n"
    "</div>\n"
    "<script>\n"
    "(function () {\n"
    "  var openBtn = document.getElementById('zypehost-support-open');\n"
    "  var modal = document.getElementById('zypehost-support-modal');\n"
    "  var input = document.getElementById('zypehost-pin-input');\n"
    "  var err = document.getElementById('zypehost-pin-error');\n"
    "  function csrf() { return document.querySelector('meta[name=\"csrf-token\"]').getAttribute('content'); }\n"
    "  openBtn.addEventListener('click', function () {\n"
    "    modal.style.display = 'flex'; input.value = ''; err.textContent = ''; input.focus();\n"
    "  });\n"
    "  document.getElementById('zypehost-pin-cancel').addEventListener('click', function () {\n"
    "    modal.style.display = 'none';\n"
    "  });\n"
    "  function submitPin() {\n"
    "    var pin = input.value.trim();\n"
    "    if (!pin) return;\n"
    "    fetch('/zypehost/support-login', {\n"
    "      method: 'POST',\n"
    "      headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': csrf(), 'Accept': 'application/json' },\n"
    "      body: JSON.stringify({ pin: pin })\n"
    "    }).then(function (r) { return r.json().then(function (d) { return { status: r.status, body: d }; }); })\n"
    "      .then(function (res) {\n"
    "        if (res.status === 200 && res.body.ok) {\n"
    "          window.location.href = res.body.redirect || '/';\n"
    "        } else {\n"
    "          err.textContent = (res.body && res.body.error) || 'Fehler.';\n"
    "        }\n"
    "      })\n"
    "      .catch(function () { err.textContent = 'Netzwerkfehler.'; });\n"
    "  }\n"
    "  document.getElementById('zypehost-pin-submit').addEventListener('click', submitPin);\n"
    "  input.addEventListener('keydown', function (e) { if (e.key === 'Enter') submitPin(); });\n"
    "})();\n"
    "</script>\n"
    "@endif\n"
    "@if(session('zypehost_support_admin_id'))\n"
    "<div style=\"position:fixed;bottom:0;left:0;right:0;background:#b45309;color:#fff;"
    "text-align:center;padding:.6rem;font-size:.85rem;z-index:10001;\">\n"
    "  Support-Modus aktiv — eingeloggt als Kunde.\n"
    "  <button id=\"zypehost-support-return\" type=\"button\" style=\"margin-left:.75rem;"
    "background:#fff;color:#b45309;border:none;border-radius:.3rem;padding:.25rem .7rem;"
    "cursor:pointer;font-weight:600;\">Zurueck zum Admin-Konto</button>\n"
    "</div>\n"
    "<script>\n"
    "document.getElementById('zypehost-support-return').addEventListener('click', function () {\n"
    "  var token = document.querySelector('meta[name=\"csrf-token\"]').getAttribute('content');\n"
    "  fetch('/zypehost/support-return', {\n"
    "    method: 'POST',\n"
    "    headers: { 'Content-Type': 'application/json', 'X-CSRF-TOKEN': token, 'Accept': 'application/json' }\n"
    "  }).then(function (r) { return r.json(); }).then(function (d) {\n"
    "    if (d.ok) window.location.href = d.redirect || '/';\n"
    "  });\n"
    "});\n"
    "</script>\n"
    "@endif\n"
    + support_marker_close + "\n"
)
s = s.replace('</body>', support_widget + '</body>')

p.write_text(s, encoding='utf-8')
PY
    info "Dashboard-Hintergrund (Schnee-Bild) eingebaut — nur sichtbar nach dem Login, Login-Seite bleibt unveraendert."
    info "Footer-Branding aktiv: 'Pterodactyl(R)' im Copyright wird automatisch zu 'ZypeHost'."
else
    info "Hinweis: wrapper.blade.php nicht gefunden, Cache-Buster/Dashboard-Hintergrund-Schritt übersprungen."
fi

# --- Step 3g: Support-PIN backend (migration, controller, command, route) -
SERVERSIDE="$ROOT_DIR/serverside"
mkdir -p "$PANEL_DIR/app/Http/Controllers/ZypeHost"
mkdir -p "$PANEL_DIR/app/Console/Commands"
cp -f "$SERVERSIDE/controllers/SupportLoginController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/SupportLoginController.php"
cp -f "$SERVERSIDE/commands/ZypeHostSupportPin.php" "$PANEL_DIR/app/Console/Commands/ZypeHostSupportPin.php"
cp -f "$SERVERSIDE/routes/zypehost-support.php" "$PANEL_DIR/routes/zypehost-support.php"
# Only copy the migration in if a migration with this exact name doesn't
# already exist (re-running install.sh must not create duplicate files).
if [[ ! -f "$PANEL_DIR/database/migrations/2026_09_23_000000_add_support_pin_to_users_table.php" ]]; then
    cp -f "$SERVERSIDE/migrations/2026_09_23_000000_add_support_pin_to_users_table.php" \
        "$PANEL_DIR/database/migrations/2026_09_23_000000_add_support_pin_to_users_table.php"
fi

# Hook the new route file into routes/web.php exactly once.
WEB_ROUTES="$PANEL_DIR/routes/web.php"
if [[ -f "$WEB_ROUTES" ]] && ! grep -q "zypehost-support.php" "$WEB_ROUTES"; then
    printf '\n// ZypeHost: support-login (see routes/zypehost-support.php)\nrequire base_path("routes/zypehost-support.php");\n' >> "$WEB_ROUTES"
fi

info "Wende Datenbank-Migration fuer Support-PIN an..."
php artisan migrate --force || fail "Migration fehlgeschlagen — pruefe die Ausgabe oben."
info "Support-Login-Backend installiert. PIN fuer einen Kunden anzeigen/erzeugen:"
info "  php artisan zypehost:support-pin kunde@example.com"

# --- Step 4: clear cache + rebuild frontend automatically -----------------
info "Leere Cache und baue das Frontend neu (das kann ein paar Minuten dauern)..."
php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
if command -v yarn >/dev/null 2>&1; then
    yarn build:production
else
    fail "yarn wurde nicht gefunden — bitte 'yarn build:production' manuell im Panel-Verzeichnis ausführen."
fi

info "Fertig. ZypeHost v10 ist installiert — Formular links, Logo rechts, echtes Impressum, neues Z-Favicon."
info ""
info "Support-Login: PIN fuer einen Kunden anzeigen/erzeugen mit:"
info "  php artisan zypehost:support-pin kunde@example.com"
info "  (mit --regenerate am Ende eine neue PIN erzwingen)"
info "Der 'Support'-Button unten rechts im Panel ist nur fuer root_admin-Accounts sichtbar."
info "Wichtig zum Favicon: Browser cachen Favicons besonders hartnäckig (unabhängig"
info "vom normalen Seiten-Cache). Falls im Tab weiter der alte Vogel zu sehen ist,"
info "obwohl die Datei hier auf dem Server jetzt richtig liegt:"
info "  - Tab komplett schliessen und neu öffnen (nicht nur neu laden)"
info "  - oder im Privat-/Inkognito-Fenster testen"
info "  - oder Browser-Cache für die Domain gezielt leeren"
info "Server-seitig geprueft werden kann das mit:"
info "  ls -la $FAVICON_DIR"
