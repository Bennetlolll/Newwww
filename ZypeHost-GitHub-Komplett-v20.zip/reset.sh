#!/usr/bin/env bash
# Restores the saved stock panel files and removes ZypeHost customizations.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"

fail(){ echo "[ZypeHost reset] ERROR: $*" >&2; exit 1; }
LATEST=""
info(){ echo "[ZypeHost reset] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"

cd "$PANEL_DIR"
LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v20-*' 2>/dev/null | sort | tail -n1 || true)"
if [[ -z "$LATEST" ]]; then LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v19-*' 2>/dev/null | sort | tail -n1 || true)"; fi
if [[ -z "$LATEST" ]]; then LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v18-*' 2>/dev/null | sort | tail -n1 || true)"; fi
if [[ -z "$LATEST" ]]; then LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v17-*' 2>/dev/null | sort | tail -n1 || true)"; fi
if [[ -z "$LATEST" ]]; then LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v15-*' 2>/dev/null | sort | tail -n1 || true)"; fi
if [[ -n "$LATEST" && -f "$LATEST/LoginFormContainer.tsx" ]]; then
    info "Stelle Originaldateien aus Backup wieder her: $LATEST"
    cp -f "$LATEST/LoginFormContainer.tsx" "$TARGET"
    [[ -f "$LATEST/wrapper.blade.php" ]] && cp -f "$LATEST/wrapper.blade.php" "$WRAPPER"
else
    fail "Kein passendes Panel-Backup gefunden. Keine Dateien wurden zurückgesetzt."
fi
# Restore assets and the root favicon from the matching install backup.
if [[ -n "$LATEST" ]]; then
    if [[ -d "$LATEST/favicons" ]]; then
        mkdir -p "$FAVICON_DIR"
        cp -af "$LATEST/favicons/." "$FAVICON_DIR/"
    fi
    if [[ -d "$LATEST/zypehost-assets" ]]; then
        rm -rf "$ASSET_DIR"
        mkdir -p "$(dirname "$ASSET_DIR")"
        cp -a "$LATEST/zypehost-assets" "$ASSET_DIR"
    elif [[ -f "$LATEST/no-previous-assets" ]]; then
        rm -rf "$ASSET_DIR"
    fi
    if [[ -f "$LATEST/public-favicon.ico" ]]; then
        cp -f "$LATEST/public-favicon.ico" "$PANEL_DIR/public/favicon.ico"
    elif [[ -f "$LATEST/no-previous-public-favicon" ]]; then
        rm -f "$PANEL_DIR/public/favicon.ico"
    fi
fi

# Restore the original auth route file captured by install.sh (it is loaded
# by RouteServiceProvider inside Pterodactyl's /auth guest group).
if [[ -n "$LATEST" && -f "$LATEST/auth.php" ]]; then
    cp -f "$LATEST/auth.php" "$PANEL_DIR/routes/auth.php"
else
    python3 - "$PANEL_DIR/routes/auth.php" <<'PYAUTH'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
if p.exists():
    s = p.read_text(encoding='utf-8')
    s = re.sub(r'(?m)^.*ZYPEHOST_OAUTH_ROUTE_REGISTRATION.*\n?', '', s)
    s = re.sub(r"(?m)^.*require_once __DIR__\s*\.\s*['\"]/zypehost-oauth\.php['\"];?.*\n?", '', s)
    p.write_text(s, encoding='utf-8')
PYAUTH
fi

# Restore the original Client API route file captured by the v20 installer.
if [[ -n "$LATEST" && -f "$LATEST/api-client.php" ]]; then
    cp -f "$LATEST/api-client.php" "$PANEL_DIR/routes/api-client.php"
else
    python3 - "$PANEL_DIR/routes/api-client.php" <<'PYAPI'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r"(?s)// ZYPEHOST_SUBDOMAIN_ROUTE_REGISTRATION_START.*?// ZYPEHOST_SUBDOMAIN_ROUTE_REGISTRATION_END\s*", "", s)
p.write_text(s, encoding='utf-8')
PYAPI
fi
if [[ -f "$LATEST/SubdomainController.php" ]]; then
    cp -f "$LATEST/SubdomainController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php"
elif [[ -f "$LATEST/no-original-SubdomainController.php" ]]; then
    rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php"
fi
if [[ -f "$LATEST/CloudflareDnsService.php" ]]; then
    mkdir -p "$PANEL_DIR/app/Services/ZypeHost"
    cp -f "$LATEST/CloudflareDnsService.php" "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php"
elif [[ -f "$LATEST/no-original-CloudflareDnsService.php" ]]; then
    rm -f "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php"
fi
for ROUTE_NAME in zypehost-subdomains-api.php zypehost-subdomains.php; do
    if [[ -f "$LATEST/$ROUTE_NAME" ]]; then cp -f "$LATEST/$ROUTE_NAME" "$PANEL_DIR/routes/$ROUTE_NAME";
    elif [[ -f "$LATEST/no-original-$ROUTE_NAME" ]]; then rm -f "$PANEL_DIR/routes/$ROUTE_NAME"; fi
done
if [[ -f "$LATEST/subdomains-migration.php" ]]; then
    cp -f "$LATEST/subdomains-migration.php" "$PANEL_DIR/database/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php"
fi
rmdir "$PANEL_DIR/app/Services/ZypeHost" 2>/dev/null || true
rmdir "$PANEL_DIR/app/Services" 2>/dev/null || true

if [[ -f "$WRAPPER" ]]; then
    python3 - "$WRAPPER" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_ADMIN_ACCESS_WIDGET', 'ZYPEHOST_SUPPORT_WIDGET'):
    s = re.sub(r'<!--\s*' + marker + r'\s*-->.*?<!--\s*/' + marker + r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PYIN
fi
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'(?m)^.*ZypeHost: support-login.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-support\.php.*\n?', '', s)
s = re.sub(r'(?m)^.*ZypeHost: email-confirmed admin access.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-admin-access\.php.*\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
rm -f "$PANEL_DIR/routes/zypehost-support.php" "$PANEL_DIR/routes/zypehost-admin-access.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/SupportLoginController.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/AdminAccessController.php"
rm -f "$PANEL_DIR/app/Console/Commands/ZypeHostSupportPin.php"
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r"(?m)^.*require_once __DIR__ . '/zypehost-oauth\.php';.*\n?", '', s)
s = re.sub(r'(?m)^.*ZypeHost OAuth: Discord and Google sign-in\.\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
if [[ -n "$LATEST" && -f "$LATEST/zypehost-oauth.php" ]]; then
    cp -f "$LATEST/zypehost-oauth.php" "$PANEL_DIR/routes/zypehost-oauth.php"
else
    rm -f "$PANEL_DIR/routes/zypehost-oauth.php"
fi
if [[ -n "$LATEST" && -f "$LATEST/zypehost.php" ]]; then
    cp -f "$LATEST/zypehost.php" "$PANEL_DIR/config/zypehost.php"
else
    rm -f "$PANEL_DIR/config/zypehost.php"
fi
if [[ -n "$LATEST" && -f "$LATEST/OAuthController.php" ]]; then
    mkdir -p "$PANEL_DIR/app/Http/Controllers/ZypeHost"
    cp -f "$LATEST/OAuthController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"
else
    rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"
    rmdir "$PANEL_DIR/app/Http/Controllers/ZypeHost" 2>/dev/null || true
fi
if [[ -n "$LATEST" && -f "$LATEST/oauth-migration.php" ]]; then
    cp -f "$LATEST/oauth-migration.php" "$PANEL_DIR/database/migrations/2026_10_31_000000_create_zypehost_oauth_accounts_table.php"
fi
# OAuth migration/table deliberately stays installed if it was created by this theme, so saved account mappings are not destroyed.
info "Theme auf den gesicherten Panel-Zustand zurückgesetzt."

php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
if command -v yarn >/dev/null 2>&1; then
    yarn build:production
elif command -v npm >/dev/null 2>&1; then
    npm run build:production
else
    info "Weder Yarn noch npm gefunden; Frontend-Build bitte manuell ausführen."
fi
info "Fertig — Pterodactyl ist auf den gesicherten Originalzustand zurückgesetzt."
