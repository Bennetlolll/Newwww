#!/usr/bin/env bash
set -Eeuo pipefail
PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v20-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v19-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v18-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v17-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v15-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v12-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || { echo 'Kein passendes ZypeHost-Backup gefunden. Nutze reset.sh oder prüfe den Backup-Ordner.'; exit 1; }
[[ -f "$LATEST/LoginFormContainer.tsx" ]] || { echo 'Backup-Datei fehlt.'; exit 1; }
cp -f "$LATEST/LoginFormContainer.tsx" "$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
if [[ -f "$LATEST/wrapper.blade.php" ]]; then cp -f "$LATEST/wrapper.blade.php" "$PANEL_DIR/resources/views/templates/wrapper.blade.php"; fi
if [[ -d "$LATEST/favicons" ]]; then cp -af "$LATEST/favicons/." "$PANEL_DIR/public/favicons/"; fi
if [[ -d "$LATEST/zypehost-assets" ]]; then
    rm -rf "$PANEL_DIR/public/themes/zypehost"
    mkdir -p "$PANEL_DIR/public/themes"
    cp -a "$LATEST/zypehost-assets" "$PANEL_DIR/public/themes/zypehost"
elif [[ -f "$LATEST/no-previous-assets" ]]; then
    rm -rf "$PANEL_DIR/public/themes/zypehost"
fi
if [[ -f "$LATEST/public-favicon.ico" ]]; then
    cp -f "$LATEST/public-favicon.ico" "$PANEL_DIR/public/favicon.ico"
elif [[ -f "$LATEST/no-previous-public-favicon" ]]; then
    rm -f "$PANEL_DIR/public/favicon.ico"
fi
if [[ -f "$LATEST/auth.php" ]]; then cp -f "$LATEST/auth.php" "$PANEL_DIR/routes/auth.php"; fi
if [[ -f "$LATEST/zypehost-oauth.php" ]]; then cp -f "$LATEST/zypehost-oauth.php" "$PANEL_DIR/routes/zypehost-oauth.php"; else rm -f "$PANEL_DIR/routes/zypehost-oauth.php"; fi
# Restore the API route registry and remove v20-only runtime classes.
if [[ -f "$LATEST/api-client.php" ]]; then
    cp -f "$LATEST/api-client.php" "$PANEL_DIR/routes/api-client.php"
else
    python3 - "$PANEL_DIR/routes/api-client.php" <<'PYAPI'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r"(?s)// ZYPEHOST_SUBDOMAIN_ROUTE_REGISTRATION_START.*?// ZYPEHOST_SUBDOMAIN_ROUTE_REGISTRATION_END\s*", "", s)
p.write_text(s, encoding='utf-8')
PYAPI
fi
if [[ -f "$LATEST/SubdomainController.php" ]]; then
    cp -f "$LATEST/SubdomainController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php"
elif [[ -f "$LATEST/no-original-SubdomainController.php" ]]; then
    rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/SubdomainController.php"
fi
if [[ -f "$LATEST/CloudflareDnsService.php" ]]; then
    mkdir -p "$PANEL_DIR/app/Services/ZypeHost"
    cp -f "$LATEST/CloudflareDnsService.php" "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php"
elif [[ -f "$LATEST/no-original-CloudflareDnsService.php" ]]; then
    rm -f "$PANEL_DIR/app/Services/ZypeHost/CloudflareDnsService.php"
fi
for ROUTE_NAME in zypehost-subdomains-api.php zypehost-subdomains.php; do
    if [[ -f "$LATEST/$ROUTE_NAME" ]]; then cp -f "$LATEST/$ROUTE_NAME" "$PANEL_DIR/routes/$ROUTE_NAME";
    elif [[ -f "$LATEST/no-original-$ROUTE_NAME" ]]; then rm -f "$PANEL_DIR/routes/$ROUTE_NAME"; fi
done
if [[ -f "$LATEST/subdomains-migration.php" ]]; then
    cp -f "$LATEST/subdomains-migration.php" "$PANEL_DIR/database/migrations/2026_11_03_000000_create_zypehost_subdomains_table.php"
fi
rmdir "$PANEL_DIR/app/Services/ZypeHost" 2>/dev/null || true
rmdir "$PANEL_DIR/app/Services" 2>/dev/null || true
if [[ -f "$LATEST/zypehost.php" ]]; then cp -f "$LATEST/zypehost.php" "$PANEL_DIR/config/zypehost.php"; else rm -f "$PANEL_DIR/config/zypehost.php"; fi
if [[ -f "$LATEST/OAuthController.php" ]]; then mkdir -p "$PANEL_DIR/app/Http/Controllers/ZypeHost"; cp -f "$LATEST/OAuthController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"; else rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"; fi
if [[ -f "$PANEL_DIR/resources/views/templates/wrapper.blade.php" ]]; then
    python3 - "$PANEL_DIR/resources/views/templates/wrapper.blade.php" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_ADMIN_ACCESS_WIDGET', 'ZYPEHOST_SUPPORT_WIDGET'):
    s = re.sub(r'<!--\s*' + marker + r'\s*-->.*?<!--\s*/' + marker + r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PYIN
fi
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'(?m)^.*ZypeHost: email-confirmed admin access.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-admin-access\.php.*\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
rm -f "$PANEL_DIR/routes/zypehost-admin-access.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/AdminAccessController.php"
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PYWEB'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding="utf-8")
s = re.sub(r"(?m)^.*require_once __DIR__.*zypehost-oauth\.php.*\n?", "", s)
p.write_text(s, encoding="utf-8")
PYWEB
fi
rmdir "$PANEL_DIR/app/Http/Controllers/ZypeHost" 2>/dev/null || true
# Keep the migration/table: it contains only provider IDs and user mappings.
cd "$PANEL_DIR"
php artisan optimize:clear
export NODE_OPTIONS=--openssl-legacy-provider
if command -v yarn >/dev/null 2>&1; then
    yarn build:production
elif command -v npm >/dev/null 2>&1; then
    npm run build:production
else
    echo "Weder Yarn noch npm gefunden; Frontend-Build bitte manuell ausführen."
fi
echo "ZypeHost Theme v20 entfernt. Backup war: $LATEST"
