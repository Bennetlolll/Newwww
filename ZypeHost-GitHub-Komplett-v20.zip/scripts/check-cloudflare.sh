#!/usr/bin/env bash
set -Eeuo pipefail
ENV_FILE="${1:-/var/www/pterodactyl/.env}"
[[ -f "$ENV_FILE" ]] || { echo "Panel-.env nicht gefunden: $ENV_FILE" >&2; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo 'python3 fehlt.' >&2; exit 1; }
python3 - "$ENV_FILE" <<'PY'
import json, re, sys, urllib.error, urllib.request
from pathlib import Path

path = Path(sys.argv[1])
values = {}
for raw in path.read_text(encoding='utf-8').splitlines():
    line = raw.strip()
    if not line or line.startswith('#'):
        continue
    if line.startswith('export '):
        line = line[7:].lstrip()
    if '=' not in line:
        continue
    key, value = line.split('=', 1)
    key = key.strip()
    value = value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in ('"', "'"):
        value = value[1:-1]
    values[key] = value

token = values.get('CLOUDFLARE_API_TOKEN', '')
zone_id = values.get('CLOUDFLARE_ZONE_ID', '')
if not token or token == 'YOUR_CLOUDFLARE_API_TOKEN':
    print('FEHLER: CLOUDFLARE_API_TOKEN fehlt oder ist noch ein Platzhalter.')
    raise SystemExit(2)
if not zone_id or zone_id == 'YOUR_BLOCKNOVA_DE_ZONE_ID':
    print('FEHLER: CLOUDFLARE_ZONE_ID fehlt oder ist noch ein Platzhalter.')
    raise SystemExit(2)

url = 'https://api.cloudflare.com/client/v4/zones/' + zone_id
request = urllib.request.Request(url, headers={
    'Authorization': 'Bearer ' + token,
    'Accept': 'application/json',
})
try:
    with urllib.request.urlopen(request, timeout=15) as response:
        payload = json.loads(response.read().decode('utf-8'))
        status = response.status
except urllib.error.HTTPError as error:
    try:
        payload = json.loads(error.read().decode('utf-8'))
    except Exception:
        payload = {}
    print('Cloudflare antwortet mit HTTP', error.code)
    for item in payload.get('errors', [])[:3]:
        print('-', item.get('message', 'Unbekannter Fehler'))
    raise SystemExit(1)
except Exception as error:
    print('Verbindungsfehler:', str(error))
    raise SystemExit(1)

if status == 200 and payload.get('success') and isinstance(payload.get('result'), dict):
    zone_name = payload['result'].get('name', '')
    if zone_name != 'blocknova.de':
        print('FEHLER: Die Zone-ID gehört zu', zone_name or 'einer unbekannten Zone', 'statt blocknova.de.')
        raise SystemExit(1)
    print('OK: Cloudflare-API erreichbar; Zone bestätigt: blocknova.de')
else:
    print('Cloudflare meldet keinen erfolgreichen Zonenabruf.')
    for item in payload.get('errors', [])[:3]:
        print('-', item.get('message', 'Unbekannter Fehler'))
    raise SystemExit(1)
PY
