<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\ZypeHost\SubdomainController;

Route::middleware('throttle:20,1')->group(function () {
    Route::get('/', [SubdomainController::class, 'index'])->name('zypehost.subdomains.index');
    Route::post('/', [SubdomainController::class, 'store'])->name('zypehost.subdomains.store');
    Route::delete('/{subdomain}', [SubdomainController::class, 'destroy'])
        ->whereNumber('subdomain')
        ->name('zypehost.subdomains.destroy');
});
