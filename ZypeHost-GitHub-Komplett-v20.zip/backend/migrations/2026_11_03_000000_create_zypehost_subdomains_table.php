<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('zypehost_subdomains')) {
            return;
        }

        Schema::create('zypehost_subdomains', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('server_id')->index();
            $table->string('server_identifier', 64);
            $table->unsignedInteger('user_id')->index();
            $table->unsignedInteger('allocation_id');
            $table->string('subdomain', 48);
            $table->string('fqdn', 255)->unique();
            $table->string('ip', 45);
            $table->unsignedSmallInteger('port');
            $table->string('a_record_id', 64);
            $table->string('srv_record_id', 64)->nullable();
            $table->timestamps();

            $table->index(['server_id', 'subdomain'], 'zypehost_subdomains_server_name_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('zypehost_subdomains');
    }
};
