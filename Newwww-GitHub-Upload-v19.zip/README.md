# ZypeHost Pterodactyl Theme v19

GitHub-fertiges Theme-Paket für das Pterodactyl-Panel von Bennetlolll. Das ZIP ist **flach aufgebaut**: `install.sh` liegt direkt im obersten Verzeichnis, damit alle Inhalte direkt in das Hauptverzeichnis des GitHub-Repositories `Bennetlolll/Newwww` hochgeladen werden können.

## Dateien und Funktionen

- ZypeHost-Login-Oberfläche mit Discord- und Google-Schaltflächen.
- Serverseitiges OAuth-Backend mit State-Prüfung, verifizierter E-Mail, automatischer Panel-Kontoerstellung und optionaler Verknüpfung vorhandener Konten.
- OAuth-Routen werden in `routes/auth.php` vor einer eventuell vorhandenen `Route::fallback(...)`-Route eingebunden. `routes/web.php` wird nicht vorausgesetzt.
- ZypeHost-Logo, Login-/Dashboard-Hintergründe und vollständiger Favicon-Satz sind im Paket enthalten. Der Installer benötigt zum Anwenden der Bilder keinen Zugriff auf GitHub Raw.
- API-Konfiguration und ein sicherer Verbindungstest für `https://zypehost.blocknova.de/api/v1/admin`.
- Backup, Deinstallation und Rücksetzen.

## GitHub-Upload

1. ZIP auf dem PC entpacken.
2. Alle Dateien und Ordner **aus dem entpackten Inhalt** direkt in das Hauptverzeichnis von `https://github.com/Bennetlolll/Newwww` hochladen.
3. Bei gleichnamigen Dateien die Repository-Version ersetzen und `Commit changes` ausführen.
4. Kontrollieren, dass `install.sh`, `README.md`, `backend/`, `scripts/` und `theme/` direkt auf der ersten Repository-Ebene liegen.
5. `.env.example` und `.gitignore` mit hochladen. Eine echte `.env` darf nicht in GitHub liegen.

Erwartete Struktur:

```text
Newwww/
├── .env.example
├── .gitignore
├── README.md
├── install.sh
├── uninstall.sh
├── reset.sh
├── backend/
│   ├── config/
│   ├── controllers/
│   ├── migrations/
│   └── routes/
├── scripts/
│   ├── check-api.sh
│   └── verify-package.sh
└── theme/
    ├── LoginFormContainer.tsx
    └── public/
        ├── favicons/
        └── themes/zypehost/
```

## Voraussetzungen

Das Paket ist auf die vom Benutzer gemeldete Panel-Struktur ausgelegt: `/var/www/pterodactyl`, `routes/auth.php`, `resources/scripts/components/auth/LoginFormContainer.tsx` und `resources/views/templates/wrapper.blade.php`.

Auf dem Server werden benötigt:

- Debian/Ubuntu oder eine vergleichbare Linux-Umgebung und Root-Rechte.
- PHP CLI und die installierten Composer-Abhängigkeiten des Panels (`vendor/autoload.php`).
- funktionierende Panel-Datenbankverbindung.
- Python 3.
- Node.js und Yarn (bevorzugt) oder npm.
- ein vorhandenes `build:production`-Script in `package.json`.

## Installation per SSH

Nachdem die Dateien im GitHub-Hauptverzeichnis committed wurden:

```bash
cd /root/Newwww
git pull --ff-only
chmod +x install.sh uninstall.sh reset.sh scripts/*.sh
PTERODACTYL_DIR=/var/www/pterodactyl bash ./install.sh 2>&1 | tee /root/zypehost-install-v19.log
```

Der Installer prüft die benötigten Panel-Dateien und Build-Werkzeuge vorab, erstellt in `storage/zypehost-backups/` eine Sicherung, kopiert das Theme, ergänzt nur fehlende `.env`-Schlüssel, führt ausschließlich die ZypeHost-OAuth-Migration aus, baut das Frontend und kontrolliert die OAuth-Routen mit `php artisan route:list`.

Wenn ein Fehler erscheint, bleibt die SSH-Sitzung normalerweise offen. Die Ausgabe steht zusätzlich in `/root/zypehost-install-v19.log`.

## Discord- und Google-OAuth aktivieren

Der Installer ergänzt fehlende Variablen in `/var/www/pterodactyl/.env`, überschreibt aber keine vorhandenen Werte. Ersetze dort die Platzhalter durch echte Daten:

Discord Developer Portal → OAuth2 → Redirects:

`https://panel.blocknova.de/auth/zypehost/discord/callback`

Google Cloud Console → APIs & Services → Credentials → OAuth Client:

`https://panel.blocknova.de/auth/zypehost/google/callback`

Zusätzliche Variablen:

- `ZYPEHOST_OAUTH_DISCORD_CLIENT_ID`
- `ZYPEHOST_OAUTH_DISCORD_CLIENT_SECRET`
- `ZYPEHOST_OAUTH_GOOGLE_CLIENT_ID`
- `ZYPEHOST_OAUTH_GOOGLE_CLIENT_SECRET`
- `ZYPEHOST_OAUTH_AUTO_REGISTER=true`
- `ZYPEHOST_OAUTH_LINK_EXISTING_EMAIL=true`

Danach:

```bash
cd /var/www/pterodactyl
php artisan optimize:clear
php artisan config:cache
php artisan route:list --path=zypehost
```

Die Callback-URLs müssen exakt mit den URLs in den Discord-/Google-Portalen übereinstimmen. Ein Live-OAuth-Test ist erst mit echten Client-ID-/Secret-Werten und erreichbarem Panel möglich.

## Admin-API prüfen

Die API-Adresse ist in `.env.example` eingetragen. Der Installer ergänzt die Variablen `ZYPEHOST_API_URL`, `ZYPEHOST_API_KEY`, `ZYPEHOST_API_KEY_HEADER` und `ZYPEHOST_API_KEY_PREFIX` in der Panel-`.env`, überschreibt vorhandene Werte jedoch nicht.

```bash
cd /root/Newwww
bash scripts/check-api.sh /var/www/pterodactyl/.env
```

Der Test liest die Laravel-`.env` als Daten und führt sie ausdrücklich **nicht** als Shell-Skript aus. HTTP 2xx bedeutet, dass der getestete GET-Aufruf erfolgreich war; 401/403 zeigen, dass der Server erreichbar ist, aber die Authentifizierung/Berechtigung nicht passt. Dieser Test ersetzt keinen Funktionsaufruf gegen einen API-Endpunkt mit dokumentiertem HTTP-Vertrag.

## Deinstallation und Wiederherstellung

```bash
cd /root/Newwww
PTERODACTYL_DIR=/var/www/pterodactyl bash ./uninstall.sh
```

`uninstall.sh` stellt die vor der Installation gesicherten Frontend-, Routing-, Favicon- und Theme-Dateien wieder her. Die OAuth-Migrationstabelle bleibt absichtlich bestehen, damit verknüpfte Kontodaten nicht ungefragt gelöscht werden. Entferne OAuth-Secrets danach bei Bedarf manuell aus der Panel-`.env`.

## Vor dem öffentlichen Start

Prüfe den Impressum-Bereich in `theme/LoginFormContainer.tsx` und trage dort die rechtlich richtigen Anbieterangaben ein. Das Paket enthält dort bewusst nur Platzhalter, damit private Anschriftsdaten nicht versehentlich mit GitHub veröffentlicht werden.

## Sicherheit

- Niemals `.env`, OAuth-Client-Secrets oder API-Keys committen.
- Nur `.env.example` mit Platzhaltern ins Repository hochladen.
- OAuth akzeptiert nur vom Anbieter als verifiziert gemeldete E-Mail-Adressen.
- Vorhandene Konten werden nur bei übereinstimmender verifizierter E-Mail verknüpft.
- Benutzerkonten mit aktivierter Pterodactyl-2FA müssen weiterhin den regulären Login mit Passwort und 2FA nutzen.

## Prüfen

Lokal oder auf GitHub Actions:

```bash
bash scripts/verify-package.sh
```

PHP-, Shell- und TSX-Syntaxprüfungen ersetzen keinen echten Build in deiner konkreten Pterodactyl-Installation. API- und OAuth-Live-Zugriffe benötigen deine geheimen Zugangsdaten und einen erreichbaren Dienst.
