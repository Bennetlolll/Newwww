<?php

$domains = array_filter(array_map('trim', explode(',', (string) env('ZYPEHOST_OAUTH_ALLOWED_DOMAINS', ''))));

return [
    'oauth' => [
        'discord' => [
            'client_id' => env('ZYPEHOST_OAUTH_DISCORD_CLIENT_ID'),
            'client_secret' => env('ZYPEHOST_OAUTH_DISCORD_CLIENT_SECRET'),
            'redirect_uri' => env('ZYPEHOST_OAUTH_DISCORD_REDIRECT_URI'),
        ],
        'google' => [
            'client_id' => env('ZYPEHOST_OAUTH_GOOGLE_CLIENT_ID'),
            'client_secret' => env('ZYPEHOST_OAUTH_GOOGLE_CLIENT_SECRET'),
            'redirect_uri' => env('ZYPEHOST_OAUTH_GOOGLE_REDIRECT_URI'),
        ],
        'auto_register' => filter_var(env('ZYPEHOST_OAUTH_AUTO_REGISTER', true), FILTER_VALIDATE_BOOLEAN),
        'link_existing_email' => filter_var(env('ZYPEHOST_OAUTH_LINK_EXISTING_EMAIL', true), FILTER_VALIDATE_BOOLEAN),
        'allowed_domains' => array_map('strtolower', array_values($domains)),
    ],
    'api' => [
        'url' => rtrim((string) env('ZYPEHOST_API_URL', 'https://zypehost.blocknova.de/api/v1/admin'), '/'),
        'key' => env('ZYPEHOST_API_KEY'),
        'key_header' => env('ZYPEHOST_API_KEY_HEADER', 'Authorization'),
        'key_prefix' => env('ZYPEHOST_API_KEY_PREFIX', 'Bearer'),
    ],
];
