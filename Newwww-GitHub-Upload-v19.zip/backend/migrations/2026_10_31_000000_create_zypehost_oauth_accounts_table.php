<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (Schema::hasTable('zypehost_oauth_accounts')) {
            return;
        }

        Schema::create('zypehost_oauth_accounts', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('provider', 24);
            $table->string('provider_user_id', 191);
            $table->unsignedInteger('user_id');
            $table->timestamps();

            $table->unique(['provider', 'provider_user_id'], 'zypehost_oauth_provider_user_unique');
            $table->index('user_id', 'zypehost_oauth_user_index');
            $table->foreign('user_id', 'zypehost_oauth_user_fk')
                ->references('id')->on('users')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('zypehost_oauth_accounts');
    }
};
