<?php

namespace Pterodactyl\Http\Controllers\ZypeHost;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\User;
use Pterodactyl\Services\Users\UserCreationService;
use Throwable;

class OAuthController extends Controller
{
    private const PROVIDERS = ['discord', 'google'];

    public function redirect(Request $request, string $provider): RedirectResponse
    {
        if (!in_array($provider, self::PROVIDERS, true)) {
            abort(404);
        }

        $clientId = config("zypehost.oauth.{$provider}.client_id");
        $clientSecret = config("zypehost.oauth.{$provider}.client_secret");
        if (!$clientId || !$clientSecret) {
            return $this->fail('Der ' . ucfirst($provider) . '-Login ist noch nicht konfiguriert. Bitte Client-ID und Client-Secret in der Panel-.env eintragen.');
        }

        $state = Str::random(64);
        $request->session()->put('zypehost_oauth_state', $state);
        $request->session()->put('zypehost_oauth_provider', $provider);

        $params = [
            'client_id' => $clientId,
            'redirect_uri' => $this->redirectUri($provider),
            'response_type' => 'code',
            'scope' => $provider === 'discord' ? 'identify email' : 'openid email profile',
            'state' => $state,
        ];

        if ($provider === 'google') {
            $params['access_type'] = 'online';
            $params['prompt'] = 'select_account';
            $url = 'https://accounts.google.com/o/oauth2/v2/auth';
        } else {
            $url = 'https://discord.com/oauth2/authorize';
        }

        return redirect()->away($url . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986));
    }

    public function callback(Request $request, string $provider): RedirectResponse
    {
        if (!in_array($provider, self::PROVIDERS, true)) {
            abort(404);
        }

        $expectedState = (string) $request->session()->pull('zypehost_oauth_state', '');
        $sessionProvider = (string) $request->session()->pull('zypehost_oauth_provider', '');
        $returnedState = (string) $request->query('state', '');

        if ($expectedState === '' || $sessionProvider !== $provider || $returnedState === '' || !hash_equals($expectedState, $returnedState)) {
            return $this->fail('Die OAuth-Sitzung ist abgelaufen oder ungültig. Bitte starte den Login erneut.');
        }

        if ($request->filled('error')) {
            return $this->fail('Die Anmeldung bei ' . ucfirst($provider) . ' wurde abgebrochen.');
        }

        $code = (string) $request->query('code', '');
        if ($code === '') {
            return $this->fail('Der OAuth-Anbieter hat keinen Autorisierungscode zurückgegeben.');
        }

        try {
            $identity = $provider === 'discord'
                ? $this->getDiscordIdentity($code)
                : $this->getGoogleIdentity($code);

            if (empty($identity['id']) || empty($identity['email']) || empty($identity['verified'])) {
                return $this->fail('Der Anbieter hat keine verifizierte E-Mail-Adresse geliefert. Bitte verifiziere deine E-Mail bei ' . ucfirst($provider) . '.');
            }

            $email = mb_strtolower(trim($identity['email']));
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return $this->fail('Der Anbieter hat eine ungültige E-Mail-Adresse zurückgegeben.');
            }

            $allowedDomains = config('zypehost.oauth.allowed_domains', []);
            if (!empty($allowedDomains)) {
                $domain = strtolower(substr(strrchr($email, '@') ?: '', 1));
                if (!in_array($domain, $allowedDomains, true)) {
                    return $this->fail('Diese E-Mail-Domain ist für die Registrierung nicht freigegeben.');
                }
            }

            $user = $this->findOrCreateUser($provider, (string) $identity['id'], $identity, $email);
            if (!$user) {
                return $this->fail('Für diese E-Mail existiert noch kein Panel-Konto und die automatische Registrierung ist deaktiviert.');
            }

            // Never turn OAuth into a way around Pterodactyl's second factor.
            // The regular username/password + TOTP flow remains available.
            if ((bool) $user->use_totp) {
                return $this->fail('Für dieses Konto ist 2FA aktiviert. Bitte nutze den normalen Login mit deinem Passwort und 2FA-Code.');
            }

            Auth::login($user, true);
            $request->session()->regenerate();

            return redirect()->intended('/');
        } catch (Throwable $exception) {
            Log::error('ZypeHost OAuth login failed', [
                'provider' => $provider,
                'exception' => get_class($exception),
                'message' => $exception->getMessage(),
            ]);

            return $this->fail('Der Login ist fehlgeschlagen. Bitte prüfe die OAuth-Konfiguration oder versuche es später erneut.');
        }
    }

    private function getDiscordIdentity(string $code): array
    {
        $token = Http::asForm()->acceptJson()->timeout(15)->post('https://discord.com/api/oauth2/token', [
            'client_id' => config('zypehost.oauth.discord.client_id'),
            'client_secret' => config('zypehost.oauth.discord.client_secret'),
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $this->redirectUri('discord'),
        ])->throw()->json();

        $accessToken = $token['access_token'] ?? null;
        if (!$accessToken) {
            throw new \RuntimeException('Discord did not return an access token.');
        }

        $profile = Http::withToken($accessToken)->acceptJson()->timeout(15)
            ->get('https://discord.com/api/users/@me')->throw()->json();

        return [
            'id' => $profile['id'] ?? null,
            'email' => $profile['email'] ?? null,
            'verified' => ($profile['verified'] ?? false) === true,
            'first_name' => $profile['global_name'] ?? $profile['username'] ?? 'Discord User',
            'last_name' => 'Discord',
        ];
    }

    private function getGoogleIdentity(string $code): array
    {
        $token = Http::asForm()->acceptJson()->timeout(15)->post('https://oauth2.googleapis.com/token', [
            'client_id' => config('zypehost.oauth.google.client_id'),
            'client_secret' => config('zypehost.oauth.google.client_secret'),
            'grant_type' => 'authorization_code',
            'code' => $code,
            'redirect_uri' => $this->redirectUri('google'),
        ])->throw()->json();

        $accessToken = $token['access_token'] ?? null;
        if (!$accessToken) {
            throw new \RuntimeException('Google did not return an access token.');
        }

        $profile = Http::withToken($accessToken)->acceptJson()->timeout(15)
            ->get('https://openidconnect.googleapis.com/v1/userinfo')->throw()->json();

        return [
            'id' => $profile['sub'] ?? null,
            'email' => $profile['email'] ?? null,
            'verified' => ($profile['email_verified'] ?? false) === true || ($profile['email_verified'] ?? null) === 'true',
            'first_name' => $profile['given_name'] ?? $profile['name'] ?? 'Google User',
            'last_name' => $profile['family_name'] ?? 'Google',
        ];
    }

    private function findOrCreateUser(string $provider, string $providerId, array $identity, string $email): ?User
    {
        return DB::transaction(function () use ($provider, $providerId, $identity, $email) {
            $linked = DB::table('zypehost_oauth_accounts')
                ->where('provider', $provider)
                ->where('provider_user_id', $providerId)
                ->first();

            if ($linked) {
                return User::query()->findOrFail($linked->user_id);
            }

            $user = null;
            if (config('zypehost.oauth.link_existing_email', true)) {
                $user = User::query()->whereRaw('LOWER(email) = ?', [$email])->first();
            }

            if (!$user) {
                if (!config('zypehost.oauth.auto_register', true)) {
                    return null;
                }

                $base = strtolower((string) ($identity['first_name'] ?? 'zypehost'));
                $base = preg_replace('/[^a-z0-9._-]/', '', Str::ascii($base)) ?: 'zypehost';
                $base = substr($base, 0, 48);
                $username = $base;
                while (User::query()->where('username', $username)->exists()) {
                    $username = substr($base, 0, 42) . Str::lower(Str::random(6));
                }

                $firstName = trim((string) ($identity['first_name'] ?? 'ZypeHost User'));
                $lastName = trim((string) ($identity['last_name'] ?? ''));
                if ($firstName === '') {
                    $firstName = 'ZypeHost User';
                }
                if ($lastName === '') {
                    $lastName = ucfirst($provider);
                }

                /** @var UserCreationService $creator */
                $creator = app(UserCreationService::class);
                $user = $creator->handle([
                    'email' => $email,
                    'username' => $username,
                    'name_first' => mb_substr($firstName, 0, 190),
                    'name_last' => mb_substr($lastName, 0, 190),
                    'password' => Str::random(72),
                    'language' => 'en',
                    'root_admin' => false,
                ]);
            }

            DB::table('zypehost_oauth_accounts')->insert([
                'provider' => $provider,
                'provider_user_id' => $providerId,
                'user_id' => $user->id,
                'created_at' => now(),
                'updated_at' => now(),
            ]);

            return $user;
        });
    }

    private function redirectUri(string $provider): string
    {
        $configured = config("zypehost.oauth.{$provider}.redirect_uri");
        return $configured ?: url('/auth/zypehost/' . $provider . '/callback');
    }

    private function fail(string $message): RedirectResponse
    {
        return redirect('/auth/login?zypehost_oauth_error=' . urlencode($message));
    }
}
