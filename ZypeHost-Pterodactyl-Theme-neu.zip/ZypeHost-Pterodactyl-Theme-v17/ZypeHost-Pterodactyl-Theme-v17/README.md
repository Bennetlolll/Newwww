# ZypeHost Pterodactyl Theme v17

Theme-Anpassungen für das Pterodactyl-Panel inklusive Discord- und Google-OAuth-Login.

## Neu in v17

- Discord OAuth2 Login direkt auf der Pterodactyl-Anmeldeseite.
- Google OAuth2 / OpenID Connect Login.
- Sichere OAuth-State-Prüfung und serverseitiger Code-Austausch; keine Client-Secrets im Browser.
- Nur verifizierte E-Mail-Adressen werden akzeptiert.
- Bestehende Panel-Konten können anhand einer verifizierten identischen E-Mail-Adresse verknüpft werden.
- Optional automatische Pterodactyl-Kontoerstellung bei der ersten OAuth-Anmeldung.
- OAuth-Verknüpfungen werden in einer eigenen Datenbanktabelle gespeichert.
- Konten mit aktivierter Pterodactyl-2FA müssen weiterhin den normalen Login mit Passwort und 2FA verwenden; OAuth umgeht 2FA ausdrücklich nicht.
- `.env.example` mit allen benötigten Einstellungen sowie API-Verbindungstest.
- Bestehende ZypeHost-Theme-Funktionen, Branding, Favicons und Dashboard-Design bleiben enthalten.

## Installation

1. ZIP auf den Panel-Server laden und entpacken.
2. Auf dem Server ausführen:

```bash
cd /root/ZypeHost-Pterodactyl-Theme-v17
chmod +x install.sh reset.sh uninstall.sh scripts/check-api.sh
PTERODACTYL_DIR=/var/www/pterodactyl bash install.sh
```

Das Installationsskript erstellt ein Backup, kopiert Login-Frontend und OAuth-Backend, registriert die Routen, führt nur die ZypeHost-OAuth-Migration aus, leert den Laravel-Cache und baut das Frontend.

## OAuth-Anbieter konfigurieren

Die Einstellungen aus `.env.example` in die echte Panel-Datei `/var/www/pterodactyl/.env` übernehmen. Nicht die echte `.env` in GitHub hochladen.

**Discord Developer Portal** – OAuth2 Redirect URL hinzufügen:

```text
https://panel.blocknova.de/auth/zypehost/discord/callback
```

Als OAuth2-Scopes `identify` und `email` verwenden.

**Google Cloud Console** – OAuth Client vom Typ „Webanwendung“ anlegen und diese autorisierte Weiterleitungs-URI hinzufügen:

```text
https://panel.blocknova.de/auth/zypehost/google/callback
```

Danach die echten Client-IDs und Client-Secrets in `/var/www/pterodactyl/.env` eintragen. `APP_URL` muss auf die öffentliche HTTPS-Adresse des Panels zeigen. Anschließend:

```bash
cd /var/www/pterodactyl
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan config:cache
```

## ZypeHost Admin API testen

Die API-Adresse ist standardmäßig:

```text
https://zypehost.blocknova.de/api/v1/admin
```

Im Theme-Ordner `.env.example` nach `.env` kopieren, echten `ZYPEHOST_API_KEY` eintragen und testen:

```bash
cp .env.example .env
nano .env
bash scripts/check-api.sh
```

Alternativ kann das Skript eine andere Env-Datei lesen:

```bash
bash scripts/check-api.sh /pfad/zur/.env
```

Der Test unterscheidet zwischen erfolgreicher Antwort, ungültigem API-Key (401), fehlenden Rechten (403), falschem Pfad (404), nicht unterstützter GET-Methode (405), Serverfehler (5xx) und Netzwerk-/DNS-Problemen. Standard ist `Authorization: Bearer <Key>`. Bei einem anderen API-Authentifizierungsheader können `ZYPEHOST_API_KEY_HEADER` und `ZYPEHOST_API_KEY_PREFIX` angepasst werden (z. B. `X-API-Key` und leerer Prefix).

## Sicherheit

- Niemals echte `.env`-Dateien, OAuth-Secrets oder API-Keys in ein öffentliches GitHub-Repository committen.
- Nur `.env.example` mit Platzhaltern veröffentlichen.
- OAuth funktioniert nur über HTTPS mit exakt übereinstimmenden Redirect-URIs.
- `ZYPEHOST_OAUTH_LINK_EXISTING_EMAIL=true` verknüpft nur, wenn Discord/Google die E-Mail-Adresse als verifiziert bestätigt.

## Deinstallation / Zurücksetzen

```bash
PTERODACTYL_DIR=/var/www/pterodactyl bash uninstall.sh
```

Oder Theme-Dateien aus dem letzten Backup wiederherstellen:

```bash
PTERODACTYL_DIR=/var/www/pterodactyl bash reset.sh
```

Die Tabelle `zypehost_oauth_accounts` bleibt bei der Deinstallation zur Sicherheit bestehen; sie enthält nur Provider-IDs und Zuordnungen, keine OAuth-Tokens oder Secrets.

## Automatische .env-Vorbereitung

Der Installer ergänzt fehlende `ZYPEHOST_*`-Variablen in `/var/www/pterodactyl/.env` mit Platzhaltern und Standardwerten. Bereits vorhandene Werte werden nicht überschrieben. Nach der Installation müssen die Platzhalter für Discord, Google und den API-Key durch echte Zugangsdaten ersetzt werden. Die echte `.env` darf **nicht** in ein öffentliches GitHub-Repository hochgeladen werden; dafür ist `.env.example` gedacht.
