<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\ZypeHost\OAuthController;

Route::middleware('throttle:20,1')->group(function () {
    Route::get('/auth/zypehost/{provider}', [OAuthController::class, 'redirect'])
        ->where('provider', 'discord|google')
        ->name('zypehost.oauth.redirect');

    Route::get('/auth/zypehost/{provider}/callback', [OAuthController::class, 'callback'])
        ->where('provider', 'discord|google')
        ->name('zypehost.oauth.callback');
});
