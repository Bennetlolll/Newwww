#!/usr/bin/env bash
# Restores the saved stock panel files and removes ZypeHost customizations.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"

fail(){ echo "[ZypeHost reset] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost reset] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"

cd "$PANEL_DIR"
if [[ -d .git ]]; then
    info "Setze Original-Dateien via git zurück..."
    git checkout -- \
        "resources/views/templates/wrapper.blade.php" \
        "resources/scripts/components/auth/LoginFormContainer.tsx" \
        "public/favicons" "public/favicon.ico" 2>/dev/null || \
        info "Eine der Dateien war schon sauber."
else
    info "Kein Git-Repo — suche letztes Backup..."
    LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v17-*' 2>/dev/null | sort | tail -n1 || true)"
    if [[ -z "$LATEST" ]]; then
        LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v15-*' 2>/dev/null | sort | tail -n1 || true)"
    fi
    if [[ -z "$LATEST" ]]; then
        LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v12-*' 2>/dev/null | sort | tail -n1 || true)"
    fi
    if [[ -z "$LATEST" ]]; then
        LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d 2>/dev/null | sort | tail -n1 || true)"
    fi
    if [[ -n "$LATEST" && -f "$LATEST/LoginFormContainer.tsx" ]]; then
        cp -f "$LATEST/LoginFormContainer.tsx" "$TARGET"
        [[ -f "$LATEST/wrapper.blade.php" ]] && cp -f "$LATEST/wrapper.blade.php" "$WRAPPER"
        [[ -d "$LATEST/favicons" ]] && cp -af "$LATEST/favicons/." "$FAVICON_DIR/"
        info "Aus Backup wiederhergestellt: $LATEST"
    else
        fail "Kein Git-Repo und kein Backup gefunden — kann nicht automatisch zurücksetzen."
    fi
fi

if [[ -f "$WRAPPER" ]]; then
    python3 - "$WRAPPER" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_ADMIN_ACCESS_WIDGET', 'ZYPEHOST_SUPPORT_WIDGET'):
    s = re.sub(r'<!--\s*' + marker + r'\s*-->.*?<!--\s*/' + marker + r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PYIN
fi
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'(?m)^.*ZypeHost: support-login.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-support\.php.*\n?', '', s)
s = re.sub(r'(?m)^.*ZypeHost: email-confirmed admin access.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-admin-access\.php.*\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
rm -f "$PANEL_DIR/routes/zypehost-support.php" "$PANEL_DIR/routes/zypehost-admin-access.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/SupportLoginController.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/AdminAccessController.php"
rm -f "$PANEL_DIR/app/Console/Commands/ZypeHostSupportPin.php"
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r"(?m)^.*require_once __DIR__ . '/zypehost-oauth\.php';.*\n?", '', s)
s = re.sub(r'(?m)^.*ZypeHost OAuth: Discord and Google sign-in\.\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
rm -f "$PANEL_DIR/routes/zypehost-oauth.php" "$PANEL_DIR/config/zypehost.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"
rmdir "$PANEL_DIR/app/Http/Controllers/ZypeHost" 2>/dev/null || true
# OAuth migration/table deliberately stays installed so saved account mappings are not destroyed.
rm -rf "$ASSET_DIR"
info "Theme und kundenbestätigter Admin-Zugriff entfernt."

php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
command -v yarn >/dev/null 2>&1 && yarn build:production || info "Bitte 'yarn build:production' manuell ausführen."
info "Fertig — Pterodactyl ist auf den gesicherten Originalzustand zurückgesetzt."
