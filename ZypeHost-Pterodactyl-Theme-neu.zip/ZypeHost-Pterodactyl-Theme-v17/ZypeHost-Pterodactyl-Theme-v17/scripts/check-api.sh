#!/usr/bin/env bash
set -Eeuo pipefail
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"
ENV_FILE="${1:-$ROOT_DIR/.env}"

if [[ ! -f "$ENV_FILE" ]]; then
    echo "[ZypeHost API] .env nicht gefunden: $ENV_FILE"
    echo "Kopiere .env.example nach .env und trage ZYPEHOST_API_KEY ein."
    exit 2
fi

set -a
# shellcheck disable=SC1090
source "$ENV_FILE"
set +a

API_URL="${ZYPEHOST_API_URL:-https://zypehost.blocknova.de/api/v1/admin}"
API_KEY="${ZYPEHOST_API_KEY:-}"
API_KEY_HEADER="${ZYPEHOST_API_KEY_HEADER:-Authorization}"
API_KEY_PREFIX="${ZYPEHOST_API_KEY_PREFIX:-Bearer}"

if ! command -v curl >/dev/null 2>&1; then
    echo "[ZypeHost API] FEHLER: curl ist nicht installiert."
    exit 2
fi

TMP_BODY="$(mktemp)"
trap 'rm -f "$TMP_BODY"' EXIT
CURL_ARGS=(--silent --show-error --location --connect-timeout 8 --max-time 20 --output "$TMP_BODY" --write-out '%{http_code}')
CURL_ARGS+=(--header 'Accept: application/json')
if [[ -n "$API_KEY" && "$API_KEY" != YOUR_* ]]; then
    if [[ -n "$API_KEY_PREFIX" ]]; then
        CURL_ARGS+=(--header "$API_KEY_HEADER: $API_KEY_PREFIX $API_KEY")
    else
        CURL_ARGS+=(--header "$API_KEY_HEADER: $API_KEY")
    fi
else
    echo "[ZypeHost API] WARNUNG: Kein echter API-Key gesetzt; prüfe nur Erreichbarkeit/öffentlichen Zugriff."
fi

echo "[ZypeHost API] Prüfe: $API_URL"
set +e
HTTP_CODE="$(curl "${CURL_ARGS[@]}" "$API_URL" 2>&1)"
CURL_EXIT=$?
set -e

if [[ $CURL_EXIT -ne 0 ]]; then
    echo "[ZypeHost API] NICHT ERREICHBAR (curl exit $CURL_EXIT)."
    echo "$HTTP_CODE"
    exit 1
fi

echo "[ZypeHost API] HTTP $HTTP_CODE"
case "$HTTP_CODE" in
    2*) echo "[ZypeHost API] OK: Der API-Endpunkt antwortet erfolgreich."; exit 0 ;;
    401) echo "[ZypeHost API] ERREICHBAR, aber API-Key fehlt oder ist ungültig (401)."; exit 1 ;;
    403) echo "[ZypeHost API] ERREICHBAR, aber der API-Key hat keine Berechtigung (403)."; exit 1 ;;
    404) echo "[ZypeHost API] Server erreichbar, aber API-Pfad nicht gefunden (404)."; exit 1 ;;
    405) echo "[ZypeHost API] Server erreichbar, aber GET wird für diesen Endpunkt nicht unterstützt (405)."; exit 1 ;;
    5*) echo "[ZypeHost API] SERVERFEHLER: API-Backend/Reverse-Proxy liefert HTTP $HTTP_CODE."; exit 1 ;;
    *) echo "[ZypeHost API] Unerwartete Antwort: HTTP $HTTP_CODE."; exit 1 ;;
esac
