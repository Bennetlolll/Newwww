#!/usr/bin/env bash
set -Eeuo pipefail
PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v17-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v15-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || LATEST="$(find "$PANEL_DIR/storage/zypehost-backups" -maxdepth 1 -mindepth 1 -type d -name 'v12-*' 2>/dev/null | sort | tail -n1 || true)"
[[ -n "$LATEST" ]] || { echo 'Kein passendes ZypeHost-Backup gefunden. Nutze reset.sh oder prüfe den Backup-Ordner.'; exit 1; }
[[ -f "$LATEST/LoginFormContainer.tsx" ]] || { echo 'Backup-Datei fehlt.'; exit 1; }
cp -f "$LATEST/LoginFormContainer.tsx" "$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
if [[ -f "$LATEST/wrapper.blade.php" ]]; then cp -f "$LATEST/wrapper.blade.php" "$PANEL_DIR/resources/views/templates/wrapper.blade.php"; fi
if [[ -d "$LATEST/favicons" ]]; then cp -af "$LATEST/favicons/." "$PANEL_DIR/public/favicons/"; fi
if [[ -f "$PANEL_DIR/resources/views/templates/wrapper.blade.php" ]]; then
    python3 - "$PANEL_DIR/resources/views/templates/wrapper.blade.php" <<'PYIN'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
for marker in ('ZYPEHOST_ADMIN_ACCESS_WIDGET', 'ZYPEHOST_SUPPORT_WIDGET'):
    s = re.sub(r'<!--\s*' + marker + r'\s*-->.*?<!--\s*/' + marker + r'\s*-->\s*', '', s, flags=re.S)
p.write_text(s, encoding='utf-8')
PYIN
fi
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r'(?m)^.*ZypeHost: email-confirmed admin access.*\n?', '', s)
s = re.sub(r'(?m)^.*routes/zypehost-admin-access\.php.*\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
rm -f "$PANEL_DIR/routes/zypehost-admin-access.php"
rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/AdminAccessController.php"
if [[ -f "$PANEL_DIR/routes/web.php" ]]; then
    python3 - "$PANEL_DIR/routes/web.php" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
s = re.sub(r"(?m)^.*require_once __DIR__ . '/zypehost-oauth\.php';.*\n?", '', s)
s = re.sub(r'(?m)^.*ZypeHost OAuth: Discord and Google sign-in\.\n?', '', s)
p.write_text(s, encoding='utf-8')
PY
fi
if [[ -f "$LATEST/zypehost-oauth.php" ]]; then cp -f "$LATEST/zypehost-oauth.php" "$PANEL_DIR/routes/zypehost-oauth.php"; else rm -f "$PANEL_DIR/routes/zypehost-oauth.php"; fi
if [[ -f "$LATEST/zypehost.php" ]]; then cp -f "$LATEST/zypehost.php" "$PANEL_DIR/config/zypehost.php"; else rm -f "$PANEL_DIR/config/zypehost.php"; fi
if [[ -f "$LATEST/OAuthController.php" ]]; then mkdir -p "$PANEL_DIR/app/Http/Controllers/ZypeHost"; cp -f "$LATEST/OAuthController.php" "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"; else rm -f "$PANEL_DIR/app/Http/Controllers/ZypeHost/OAuthController.php"; fi
rmdir "$PANEL_DIR/app/Http/Controllers/ZypeHost" 2>/dev/null || true
# Keep the migration/table: it contains only provider IDs and user mappings.
cd "$PANEL_DIR"
php artisan optimize:clear
export NODE_OPTIONS=--openssl-legacy-provider
yarn build:production
echo "ZypeHost Theme entfernt. Backup war: $LATEST"
