#!/usr/bin/env bash
# ZypeHost Pterodactyl Theme v10 — installer
# v10 adds: swapped login card layout (form left / logo right), a real
# Impressum instead of placeholders, a redesigned brand mark, and a new
# "Z" favicon set that replaces Pterodactyl's default falcon favicon.
set -Eeuo pipefail

PANEL_DIR="${PTERODACTYL_DIR:-/var/www/pterodactyl}"
ROOT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
SRC="$ROOT_DIR/theme/public/themes/zypehost"
FAVICON_SRC="$ROOT_DIR/theme/public/favicons"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$PANEL_DIR/storage/zypehost-backups/v10-$STAMP"
TARGET="$PANEL_DIR/resources/scripts/components/auth/LoginFormContainer.tsx"
WRAPPER="$PANEL_DIR/resources/views/templates/wrapper.blade.php"
ASSET_DIR="$PANEL_DIR/public/themes/zypehost"
FAVICON_DIR="$PANEL_DIR/public/favicons"

fail(){ echo "[ZypeHost v10] ERROR: $*" >&2; exit 1; }
info(){ echo "[ZypeHost v10] $*"; }

[[ -f "$PANEL_DIR/artisan" ]] || fail "Pterodactyl nicht gefunden: $PANEL_DIR"
[[ -f "$TARGET" ]] || fail "LoginFormContainer.tsx nicht gefunden: $TARGET"
[[ -f "$SRC/background.jpeg" ]] || fail "background.jpeg fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-logo.png" ]] || fail "zypehost-logo.png fehlt im Theme-Ordner"
[[ -f "$SRC/zypehost-icon.png" ]] || fail "zypehost-icon.png fehlt im Theme-Ordner"
[[ -f "$SRC/dashboard-bg.jpg" ]] || fail "dashboard-bg.jpg fehlt im Theme-Ordner"
[[ -d "$FAVICON_SRC" ]] || fail "favicons-Ordner fehlt im Theme-Ordner"

mkdir -p "$BACKUP"
cp -a "$TARGET" "$BACKUP/LoginFormContainer.tsx"
[[ -f "$WRAPPER" ]] && cp -a "$WRAPPER" "$BACKUP/wrapper.blade.php" || true
[[ -d "$FAVICON_DIR" ]] && cp -a "$FAVICON_DIR" "$BACKUP/favicons" || true
[[ -f "$PANEL_DIR/.env" ]] && cp -a "$PANEL_DIR/.env" "$BACKUP/.env" || true
info "Backup gespeichert unter: $BACKUP"

# --- Step 1: HARD RESET so nothing from v2/v3/v4/v5 can survive -----------
cd "$PANEL_DIR"
if [[ -d .git ]]; then
    info "Git-Repo erkannt — setze wrapper.blade.php und LoginFormContainer.tsx auf den Original-Stand zurück..."
    git checkout -- \
        "resources/views/templates/wrapper.blade.php" \
        "resources/scripts/components/auth/LoginFormContainer.tsx" 2>/dev/null || \
        info "Hinweis: git checkout konnte eine der Dateien nicht zurücksetzen (evtl. schon sauber)."
else
    info "Kein Git-Repo gefunden — entferne alte ZypeHost-Marker per Textsuche stattdessen."
    if [[ -f "$WRAPPER" ]]; then
        python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import re, sys
p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
# strip every historical marker pair, whatever version made it
for marker in ('ZYPEHOST_V6_ASSETS', 'ZYPEHOST_V5_ASSETS', 'ZYPEHOST_V4_ASSETS', 'ZYPEHOST_V3_ASSETS', 'ZYPEHOST_V2_ASSETS'):
    s = re.sub(r'<!--\s*' + re.escape(marker) + r'\s*-->.*?<!--\s*/' + re.escape(marker) + r'\s*-->\s*', '', s, flags=re.S)
# safety net: also strip any leftover comment block that just mentions zypehost
s = re.sub(r'<!--[^>]*zypehost[^>]*-->.*?<!--[^>]*/[^>]*zypehost[^>]*-->\s*', '', s, flags=re.S | re.I)
p.write_text(s, encoding='utf-8')
PY
    fi
fi

# --- Step 2: wipe old theme assets completely, then lay down fresh ones ---
rm -rf "$ASSET_DIR"
mkdir -p "$ASSET_DIR"
cp -f "$SRC/background.jpeg" "$ASSET_DIR/background.jpeg"
cp -f "$SRC/zypehost-logo.png" "$ASSET_DIR/zypehost-logo.png"
cp -f "$SRC/zypehost-icon.png" "$ASSET_DIR/zypehost-icon.png"
cp -f "$SRC/dashboard-bg.jpg" "$ASSET_DIR/dashboard-bg.jpg"

# --- Step 3: write the new single-card component (full overwrite) --------
cp -f "$ROOT_DIR/theme/LoginFormContainer.tsx" "$TARGET"

# --- Step 3b: replace the default Pterodactyl favicon with the ZypeHost
#     "Z" mark (same filenames, so no blade/template edits are needed) ----
mkdir -p "$FAVICON_DIR"
# Overwrite EVERY icon file Pterodactyl's default favicon set ships with
# (android-icon-*, apple-icon-*, ms-icon-*, mstile-*, favicon-96x96, the
# favicon.ico that lives inside public/favicons/, plus the Safari pinned-tab
# SVG) so no old falcon file can survive in any size/format a browser might
# prefer over the ones we already knew about.
cp -f "$FAVICON_SRC"/*.png "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC"/*.svg "$FAVICON_DIR/" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$FAVICON_DIR/favicon.ico" 2>/dev/null || true
cp -f "$FAVICON_SRC/favicon.ico" "$PANEL_DIR/public/favicon.ico" 2>/dev/null || true
info "Favicon ersetzt (Falke -> Z), komplettes Set inkl. Apple/Android/MS-Icons und Safari-Pinned-Tab."

# --- Step 3c: force browsers to actually fetch the new favicons -----------
# Pterodactyl's default wrapper.blade.php links to /favicons/... with no
# cache-busting query string at all, so browsers that already cached the
# old falcon icons keep showing them forever even though the files on disk
# are correct. Fix: append/refresh a "?v=<timestamp>" query on every
# favicon-related href/content in wrapper.blade.php so each install forces
# a guaranteed-fresh fetch, independent of any browser cache.
if [[ -f "$WRAPPER" ]]; then
    FAVICON_STAMP="$STAMP" python3 - "$WRAPPER" <<'PY'
from pathlib import Path
import os, re, sys

p = Path(sys.argv[1])
s = p.read_text(encoding='utf-8')
stamp = os.environ['FAVICON_STAMP']

def bust(match):
    attr, path = match.group(1), match.group(2)
    path = re.sub(r'\?v=[^"\']*', '', path)  # drop any previous cache-buster
    return f'{attr}="{path}?v={stamp}"'

# Matches href="/favicons/..." and content="/favicons/..." (browserconfig meta)
s = re.sub(r'(href|content)="(/favicons/[^"]*)"', bust, s)
p.write_text(s, encoding='utf-8')
PY
    info "Cache-Buster auf Favicon-Links in wrapper.blade.php gesetzt (?v=$STAMP) — Browser MUSS neu laden."

    # --- Step 3d: dashboard-only background (never on the login screen) --
    # wrapper.blade.php already knows whether someone is logged in — it uses
    # Auth::user() further down to decide whether to print window.PterodactylUser.
    # We reuse that exact same check on the <body> tag: only when the user IS
    # authenticated (dashboard / server pages) do we add a class that paints
    # the new background. The login/forgot-password/reset screens run through
    # AuthenticationRouter with no authenticated user, so Auth::user() is null
    # there and the class — and therefore the image — never appears.
    python3 - "$WRAPPER" "$STAMP" <<'PY'
from pathlib import Path
import re, sys

p = Path(sys.argv[1])
stamp = sys.argv[2]
s = p.read_text(encoding='utf-8')

body_tag_match = re.search(r'<body[^>]*>', s)
already_patched = bool(body_tag_match) and 'zypehost-dashboard-bg' in body_tag_match.group(0)

body_re = re.compile(r'<body class="\{\{\s*\$css\[\'body\'\]\s*\?\?\s*\'([^\']*)\'\s*\}\}">')
if already_patched:
    pass  # already patched by a previous install run, leave the <body> tag alone
elif body_re.search(s):
    s = body_re.sub(
        lambda m: (
            '<body class="{{ $css[\'body\'] ?? \'' + m.group(1) + '\' }}'
            ' @if(!is_null(Auth::user())) zypehost-dashboard-bg @endif">'
        ),
        s,
        count=1,
    )
else:
    # Fallback: whatever the body tag looks like, just tack the same
    # conditional class onto it so this still works on unexpected markup.
    s = re.sub(
        r'<body class="([^"]*)">',
        lambda m: f'<body class="{m.group(1)} @if(!is_null(Auth::user())) zypehost-dashboard-bg @endif">',
        s,
        count=1,
    )

css_block = (
    "<style>\n"
    ".zypehost-dashboard-bg {\n"
    "  background:\n"
    "    linear-gradient(rgba(8,12,18,.55), rgba(8,12,18,.72)),\n"
    f"    url('/themes/zypehost/dashboard-bg.jpg?v={stamp}') center center / cover no-repeat fixed !important;\n"
    "}\n"
    "/* Pterodactyl's panels/cards use Tailwind colour utilities, which are\n"
    "   fully opaque by default and completely cover any body background.\n"
    "   Tailwind's color utilities read their alpha from the --tw-bg-opacity\n"
    "   custom property, so lowering it (instead of guessing exact class\n"
    "   names, which change between panel versions) lets the new background\n"
    "   image show through everywhere at once. Modals/popups are kept solid\n"
    "   via #modal-portal so dialogs stay easy to read. */\n"
    ".zypehost-dashboard-bg * {\n"
    "  --tw-bg-opacity: 0.55 !important;\n"
    "}\n"
    ".zypehost-dashboard-bg #modal-portal *,\n"
    ".zypehost-dashboard-bg [role='dialog'] * {\n"
    "  --tw-bg-opacity: 0.94 !important;\n"
    "}\n"
    "/* Nicer buttons + server-list rows, panel-version independent (no core\n"
    "   TSX files touched, so this survives Pterodactyl updates). */\n"
    "button, a[href^='/server/'] {\n"
    "  transition: transform .12s ease, filter .12s ease, box-shadow .12s ease !important;\n"
    "}\n"
    "button:hover {\n"
    "  filter: brightness(1.12);\n"
    "  transform: translateY(-1px);\n"
    "}\n"
    "button:active {\n"
    "  transform: translateY(0);\n"
    "  filter: brightness(0.96);\n"
    "}\n"
    "a[href^='/server/'] {\n"
    "  border-radius: 0.75rem !important;\n"
    "  overflow: hidden;\n"
    "}\n"
    "a[href^='/server/']:hover {\n"
    "  transform: translateY(-2px);\n"
    "  box-shadow: 0 10px 24px rgba(0,0,0,.35) !important;\n"
    "}\n"
    "</style>\n"
)
if '.zypehost-dashboard-bg {' not in s:
    s = s.replace('</head>', css_block + '</head>')
else:
    s = re.sub(r"<style>\n\.zypehost-dashboard-bg.*?</style>\n", css_block, s, flags=re.S)

# --- Step 3e: rebrand the built-in "Pterodactyl® © 2015 - <year>" footer -
# That footer text lives inside Pterodactyl's own React components (not
# something this theme ships/overwrites), and its exact file/markup shifts
# between panel versions. Instead of guessing the source file, a small,
# self-contained script finds that exact text wherever it renders and swaps
# only the "Pterodactyl(R)" part for "ZypeHost", leaving "(c) 2015 - year"
# intact. Wrapped in a marker so re-running install.sh never duplicates it.
footer_marker_open = '<!-- ZYPEHOST_FOOTER_BRAND -->'
footer_marker_close = '<!-- /ZYPEHOST_FOOTER_BRAND -->'
s = re.sub(
    re.escape(footer_marker_open) + r'.*?' + re.escape(footer_marker_close) + r'\s*',
    '',
    s,
    flags=re.S,
)
footer_script = (
    footer_marker_open + "\n"
    "<script>\n"
    "(function () {\n"
    "  function rebrand() {\n"
    "    var walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null);\n"
    "    var node;\n"
    "    while ((node = walker.nextNode())) {\n"
    "      if (node.nodeValue.indexOf('Pterodactyl') !== -1) {\n"
    "        node.nodeValue = node.nodeValue.replace(/Pterodactyl\\u00AE?/g, 'ZypeHost');\n"
    "      }\n"
    "    }\n"
    "  }\n"
    "  // Debounced: the server console streams log lines into the DOM\n"
    "  // constantly, so an observer callback that runs on every single\n"
    "  // mutation would re-scan the whole page far too often. Collapse\n"
    "  // bursts down to at most one scan per second instead.\n"
    "  var pending = null;\n"
    "  function scheduleRebrand() {\n"
    "    if (pending) return;\n"
    "    pending = setTimeout(function () { pending = null; rebrand(); }, 1000);\n"
    "  }\n"
    "  document.addEventListener('DOMContentLoaded', function () {\n"
    "    rebrand();\n"
    "    new MutationObserver(scheduleRebrand).observe(document.body, { childList: true, subtree: true });\n"
    "  });\n"
    "})();\n"
    "</script>\n"
    + footer_marker_close + "\n"
)
s = s.replace('</body>', footer_script + '</body>')

p.write_text(s, encoding='utf-8')
PY
    info "Dashboard-Hintergrund (Schnee-Bild) eingebaut — nur sichtbar nach dem Login, Login-Seite bleibt unveraendert."
    info "Footer-Branding aktiv: 'Pterodactyl(R)' im Copyright wird automatisch zu 'ZypeHost'."
else
    info "Hinweis: wrapper.blade.php nicht gefunden, Cache-Buster/Dashboard-Hintergrund-Schritt übersprungen."
fi

# --- Step 4: clear cache + rebuild frontend automatically -----------------
info "Leere Cache und baue das Frontend neu (das kann ein paar Minuten dauern)..."
php artisan optimize:clear || true
export NODE_OPTIONS=--openssl-legacy-provider
if command -v yarn >/dev/null 2>&1; then
    yarn build:production
else
    fail "yarn wurde nicht gefunden — bitte 'yarn build:production' manuell im Panel-Verzeichnis ausführen."
fi

info "Fertig. ZypeHost v10 ist installiert — Formular links, Logo rechts, echtes Impressum, neues Z-Favicon."
info ""
info "Wichtig zum Favicon: Browser cachen Favicons besonders hartnäckig (unabhängig"
info "vom normalen Seiten-Cache). Falls im Tab weiter der alte Vogel zu sehen ist,"
info "obwohl die Datei hier auf dem Server jetzt richtig liegt:"
info "  - Tab komplett schliessen und neu öffnen (nicht nur neu laden)"
info "  - oder im Privat-/Inkognito-Fenster testen"
info "  - oder Browser-Cache für die Domain gezielt leeren"
info "Server-seitig geprueft werden kann das mit:"
info "  ls -la $FAVICON_DIR"
