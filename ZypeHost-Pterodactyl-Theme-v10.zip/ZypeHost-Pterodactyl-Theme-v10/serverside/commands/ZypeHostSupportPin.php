<?php

namespace Pterodactyl\Console\Commands;

use Illuminate\Console\Command;
use Pterodactyl\Models\User;

class ZypeHostSupportPin extends Command
{
    protected $signature = 'zypehost:support-pin {email} {--regenerate}';

    protected $description = 'Zeigt die feste Support-PIN eines Kunden (erzeugt automatisch eine, falls noch keine existiert).';

    public function handle(): int
    {
        $user = User::where('email', $this->argument('email'))->first();
        if (!$user) {
            $this->error('Kein User mit dieser E-Mail gefunden.');

            return 1;
        }

        if ($user->root_admin) {
            $this->error('Admin-Accounts bekommen keine Support-PIN (koennen nicht per PIN uebernommen werden).');

            return 1;
        }

        if ($this->option('regenerate') || !$user->support_pin) {
            $user->support_pin = (string) random_int(10000000, 99999999);
            $user->save();
        }

        $this->info("Support-PIN fuer {$user->email}: {$user->support_pin}");

        return 0;
    }
}
