<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('users', 'support_pin')) {
            Schema::table('users', function (Blueprint $table) {
                $table->string('support_pin', 32)->nullable()->unique()->after('root_admin');
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('users', 'support_pin')) {
            Schema::table('users', function (Blueprint $table) {
                $table->dropColumn('support_pin');
            });
        }
    }
};
