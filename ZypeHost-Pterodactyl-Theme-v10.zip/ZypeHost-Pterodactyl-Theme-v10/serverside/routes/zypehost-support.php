<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\ZypeHost\SupportLoginController;

Route::middleware(['web', 'throttle:10,1'])->group(function () {
    Route::post('/zypehost/support-login', [SupportLoginController::class, 'attempt']);
    Route::post('/zypehost/support-return', [SupportLoginController::class, 'returnToAdmin']);
    Route::get('/zypehost/support-pin/{email}', [SupportLoginController::class, 'pinFor']);
});
