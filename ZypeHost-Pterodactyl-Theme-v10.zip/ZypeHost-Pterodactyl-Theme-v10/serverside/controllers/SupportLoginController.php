<?php

namespace Pterodactyl\Http\Controllers\ZypeHost;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\User;

/**
 * ZypeHost support-login: lets an already-authenticated root_admin enter a
 * customer's fixed Support-PIN to log in as that customer for
 * troubleshooting. The PIN alone is never sufficient — the current session
 * must already belong to a root_admin, every attempt (success AND failure)
 * is logged, and target accounts that are themselves root_admin can never
 * be reached this way.
 */
class SupportLoginController extends Controller
{
    public function attempt(Request $request)
    {
        $request->validate(['pin' => 'required|string|max:32']);

        $admin = $request->user();
        if (!$admin || !$admin->root_admin) {
            abort(403, 'Nur Admins duerfen die Support-PIN benutzen.');
        }

        $target = User::where('support_pin', $request->input('pin'))->first();

        if (!$target || $target->root_admin) {
            Log::warning('[ZypeHost] Fehlgeschlagener Support-Login-Versuch', [
                'admin_id' => $admin->id,
                'admin_email' => $admin->email,
                'ip' => $request->ip(),
                'time' => now()->toDateTimeString(),
            ]);

            return response()->json(['error' => 'Ungueltige Support-PIN.'], 422);
        }

        Log::info('[ZypeHost] Support-Login durchgefuehrt', [
            'admin_id' => $admin->id,
            'admin_email' => $admin->email,
            'target_id' => $target->id,
            'target_email' => $target->email,
            'ip' => $request->ip(),
            'time' => now()->toDateTimeString(),
        ]);

        $request->session()->put('zypehost_support_admin_id', $admin->id);
        Auth::login($target);
        $request->session()->regenerate();

        return response()->json(['ok' => true, 'redirect' => '/']);
    }

    public function returnToAdmin(Request $request)
    {
        $adminId = $request->session()->get('zypehost_support_admin_id');
        if (!$adminId) {
            return response()->json(['error' => 'Keine aktive Support-Sitzung.'], 422);
        }

        $admin = User::find($adminId);
        if (!$admin || !$admin->root_admin) {
            return response()->json(['error' => 'Admin-Konto nicht gefunden oder keine Admin-Rechte mehr.'], 422);
        }

        Log::info('[ZypeHost] Rueckkehr aus Support-Login', [
            'admin_id' => $admin->id,
            'ip' => $request->ip(),
            'time' => now()->toDateTimeString(),
        ]);

        $request->session()->forget('zypehost_support_admin_id');
        Auth::login($admin);
        $request->session()->regenerate();

        return response()->json(['ok' => true, 'redirect' => '/']);
    }

    /**
     * Fallback web endpoint (in case the artisan command below isn't
     * auto-discovered on some installs) to view/generate a customer's
     * fixed support PIN. Still gated by root_admin on the CURRENT session.
     */
    public function pinFor(Request $request, string $email)
    {
        $admin = $request->user();
        if (!$admin || !$admin->root_admin) {
            abort(403);
        }

        $target = User::where('email', $email)->first();
        if (!$target) {
            return response()->json(['error' => 'User nicht gefunden.'], 404);
        }

        if (!$target->support_pin) {
            $target->support_pin = (string) random_int(10000000, 99999999);
            $target->save();
        }

        return response()->json(['email' => $target->email, 'pin' => $target->support_pin]);
    }
}
